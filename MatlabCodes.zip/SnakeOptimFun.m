% function y=SnakeOptimFun()
% For snake contour model
% "Snakes: Active Contour Models"
% A uniform frame of adding the global guidance field to snake model

% Replace the lightings with the global "skeleton length* skeleton distance"
% Optimize the results after global curve templates

% Modified from SnakeContour3;

    ConsidImg=CellConsidImg{Num};
    CellModPix=CellCellModPix{Num};
    
    % Shrink the image and the corresponding points
    ConsidImg=imresize(ConsidImg,[nR,nC]);
    %EstShape=[EstShape(:,1)/colR,EstShape(:,2)/rowR];
    for i=1:4
        CellModPix{i}=floor([CellModPix{i}(:,1)/colR,CellModPix{i}(:,2)/rowR]);
    end
    
    
    %% Perform local search
    
    % Parameter values
    alpha_val = 0.05;  % Controls tension, first order smoothness
    beta_val = 0.05;  % Controls rigidity, second order smoothness
%     alpha_val = 0.0;  % Controls tension, first order smoothness
%     beta_val = 0.0;  % Controls rigidity, second order smoothness
    
    gamma_val = 0.5;  %  Step size, the coefficient before the Xt-Xt-1, the larger gamma_val, the larger Xt
    %gamma_val = 0.2;  %  Step size
    %kappa_val = 0.15;  % Controls enegry term
    kappa_val = 0.1;  % Controls enegry term, the coefficient before the exterior energy
    weline_val = 1e3;  % wl, we, wt: Weights for line, edge and terminal enegy components
    weedge_val = 0.00;
    %weterm_val = 0.01;
    weterm_val = 0.0;
    inter_val = 20;  % Number of iteration

    IniAlpha=0.05;  % The weight w.r.t. the vector direction preservation
    IniAlpha1=0.1; % The weight w.r.t. the vector length preservation
%     IniAlpha=0.05;  % The weight w.r.t. the vector direction preservation
%     IniAlpha1=0.3; % The weight w.r.t. the vector length preservation

    % Making the snake move
    smth=(ImgLenDist-min(ImgLenDist(:)))/(max(ImgLenDist(:))-min(ImgLenDist(:)));  % Employ distance/length directly, By DistLenImage.m, DFSaDistLenImage1.m;
    
    %CellQuadrantId=cell(4,1);
    
    CellCellDensePit=cell(4,1);
    AllId=find(smth>-1);
    for kk=1:4
       while  min(CellModPix{kk}(:,1))<1||min(CellModPix{kk}(:,2))<1||max(CellModPix{kk}(:,1))>nC||max(CellModPix{kk}(:,2))>nR
           CellModPix{kk}=CellModPix{kk}(1:floor(0.95*length(CellModPix{kk})),:);
       end
        smoothCellModPix=bs_curve_interpo_Fun(CellModPix{kk}(1:10:end,:),8);
        [xs,ys]=deal(smoothCellModPix(:,1)',smoothCellModPix(:,2)');

        %tQuadrantId=ObtainQuadrantRegion(tBranchPit,tvT,tvN,[nR,nC],kk);  
        %tQuadrantId=ObtainQuadrantRegion1(tBranchPit,tvT,tvN,[nR,nC],kk);  
        %CellQuadrantId{kk}=tQuadrantId;
        smthTe=smth;  
        % smthTe(setdiff(AllId,tQuadrantId))=1; % Only consider one quadrant

        [~,OptDensePit{Num,kk},CellCellDensePit{kk}]=interate1_3(smthTe, xs, ys, alpha_val, beta_val, gamma_val, kappa_val, weline_val, weedge_val, weterm_val, inter_val,IniAlpha,IniAlpha1);
        %[~,OptDensePit{Num,kk},CellCellDensePit{kk}] = interate(smthTe, xs, ys, alpha_val, beta_val, gamma_val, kappa_val, weline_val, weedge_val, weterm_val, inter_val); % For OriSnakeWithoutGGF.mat 
    end
    %pause(3);


%%
%
figure; imshow(ConsidImg);
smoothCentFivePit=bs_curve_interpo_Fun(CentFivePit,20);
hold on; plot(smoothCentFivePit(:,1),smoothCentFivePit(:,2),'-or','MarkerSize',2); % Optimized points
for kk=1:4
    hold on; plot(OptDensePit{Num,kk}(:,1),OptDensePit{Num,kk}(:,2),'-or','MarkerSize',2); % Optimized points
    hold on; text(OptDensePit{Num,kk}(end,1),OptDensePit{Num,kk}(end,2),num2str(kk),'fontsize',16); % Optimized points
    hold on; plot(CellModPix{kk}(:,1),CellModPix{kk}(:,2),'-b'); % Initial points
end

for kk=1:7 % Ground truth points
    tPits=GroundTruthShape{Num,kk};
    tPits=[tPits(:,1)/colR,tPits(:,2)/rowR];
    hold on; plot(tPits(:,1),tPits(:,2),'-*g','MarkerSize',2);
end
%
% save QuadrantInfor2.mat CellQuadrantId tvT tvN