imgPepper_t=double(imageSN)/255;

[T1,Thresh] = edge(imgPepper_t,'canny');
TT = edge(imgPepper_t,'canny',Thresh+[-0.3,+0.3]);
%figure; imshow(TT);

[nR,nC,~]=size(imageSN);

tSearchPit=[];
SnC=20;
for i=1:SnC
    iC=round(nC*i/(SnC+1));  tSearchWid=round(nR/3);
    tFlag=0;  r=1;
    while ~tFlag && r<=tSearchWid
        if TT(r,iC)
            tFlag=1;  tSearchPit=[tSearchPit;iC,r];  break; 
        end % if 
        r=r+1;
    end % while 
    
    tFlag=0;  r=1;
    while ~tFlag && r<=tSearchWid
        if TT(nR-r,iC)
            tFlag=1; tSearchPit=[tSearchPit;iC,nR-r];  break; 
        end % if 
        r=r+1;
    end % while 
end % for i
%hold on; plot(tSearchPit(:,1),tSearchPit(:,2),'*r');

[zb, ab, bb, alphab] = fitellipse(tSearchPit', 'linear');
tBndPit=transpose(EllipseFitPit(zb, ab, bb, alphab, 18));
tBndPit(:,1)=max(4,min(nC-3,tBndPit(:,1)));  tBndPit(:,2)=max(4,min(nR-3,tBndPit(:,2)));

%hold on; plot(tBndPit(:,1),tBndPit(:,2),'-ob');

%%
tMask=poly2mask(tBndPit(:,1),tBndPit(:,2),nR,nC);
%se = strel('disk',round(min(nR,nC)/5));
se = strel('disk',round(min(nR,nC)/10));
erodedBM = imerode(tMask,se);

%%
imgPepper_tt=imageSN;
imgPepper_tt=double(imgPepper_tt)/255;
[tI,tJ]=find(imgPepper_tt.*erodedBM>0.95|imgPepper_tt.*erodedBM<0.05);
figure; imshow(imgPepper_tt);
%hold on; plot(tJ(:),tI(:),'.r');

ttImg=zeros(size(imgPepper_tt));
ttImg((tJ(:)-1)*nR+tI(:))=1;
figure; imshow(ttImg);

se = strel('ball',5,5);
ttImgExp = imdilate(ttImg,se); ttImgExp=ttImgExp>min(ttImgExp(:));
figure; imshow(ttImgExp);

%%
[B,L] = bwboundaries(ttImgExp);
%figure; imshow(ttImgExp);  hold on
FinalImg=imgPepper_tt;

for k = 1:length(B)
   boundary = B{k};
   if length(boundary)>2*pi*5
       continue;
   end % if 
   IniRetainFlag=ones(size(ttImgExp));
   [teI,teJ]=find(L==k);
   IniRetainFlag((teJ(:)-1)*nR+teI(:))=0;
   
   IniOriImg=imgPepper_tt.*repmat(IniRetainFlag,[1,1,size(imgPepper_tt,3)]);
    InclinePoissonEmbed=PoissonPatching(IniOriImg,IniRetainFlag); % Poisson patching: Delta P=0
    FinalImg((teJ(:)-1)*nR+teI(:))=InclinePoissonEmbed((teJ(:)-1)*nR+teI(:));
end
if max(FinalImg(:))<=1  FinalImg=uint8(FinalImg*255);  end
figure; imshow(FinalImg);

imageSN=FinalImg;
