function [CellModPixCorrect,tAbnId]=AbnormShapCorrect(s0,CentFivePit,CellModPix)
% For detecting abnormal shape branches with curve templates, and replace with the average shape
% with Procrustes transformation

CellModPixCorrect=CellModPix;
NumDensePit=zeros(4,1);

%tSimpId=[3,3;4,1;6,2;7,4];
tSimpId=[3,3;4,2;6,1;7,4];
tSimpId2=[1,6;2,4;3,3;4,7];

tAngBias=zeros(4,4); 

tSimCellModPix=cell(size(CellModPix));
tCors0=cell(size(CellModPix)); % The corresponding points on mean shape s0
% Interpolate the same number of points with the mean shape
% Compute the bias between the direction vector
for kk=1:4
    tSimCellModPix{kk}=bs_curve_interpo_Fun(CellModPix{kk}(1:10:end,:),5);
    
    tSimVec=tSimCellModPix{kk}(2:end,:)-tSimCellModPix{kk}(1:end-1,:);
    tId=find(tSimpId(:,2)==kk);
    
    tCors0{kk}=s0((tSimpId(tId,1)-1)*5+1:(tSimpId(tId,1)-1)*5+5,:);
    
    % Scale tCors0{kk} to the same size as tSimCellModPix{kk}
    tPits=ScaleVesselBranch(tCors0{kk},tSimCellModPix{kk});
    
    ts0Vec=tPits(2:end,:)-tPits(1:end-1,:);
    
    for j=1:4
        tAngBias(kk,j)=acos(dot(tSimVec(j,:),ts0Vec(j,:))/norm(tSimVec(j,:))/norm(ts0Vec(j,:)));
    end
    
    NumDensePit(kk)=size(CellModPix{kk},1);
end
tSumAng=mean(tAngBias,2);

% Judge whether the bias quantity is abnormal or not!!!
tAbnId=find(tSumAng>pi/4);

if isempty(tAbnId) return; end

tRetainId=setdiff([1:4],tAbnId);
tRetainSimCellModPix=[];
tRetainCors0=[];
for i=1:length(tRetainId)
    tRetainSimCellModPix=[tRetainSimCellModPix;tSimCellModPix{tRetainId(i)}];
    tRetainCors0=[tRetainCors0;tCors0{tRetainId(i)}];
end

%hold on; plot(tRetainSimCellModPix(:,1),tRetainSimCellModPix(:,2),'*g');

% Estimate the abnormal part with Procrustes transformation
%size(CentFivePit),size(tRetainSimCellModPix),size(s0(1:5,:)),size(tCors0)
[d,Z,transform]=procrustes([CentFivePit;tRetainSimCellModPix],[s0(1:5,:);tRetainCors0]);
tEstShape=transform.b*s0*transform.T+repmat(mean(transform.c),size(s0,1),1);

% Output the corrected one 
ttLenA=length(tAbnId);
if ttLenA
    for kk=1:ttLenA
        ttId1=tAbnId(kk);  % 1-4
        ttId2=tSimpId2(ttId1,2); % 1-7
        tPits=[CellModPix{ttId1}(1,:);tEstShape((ttId2-1)*5+1:ttId2*5,:)];
        %hold on; plot(tPits(:,1),tPits(:,2),'-<g'); % 
        CellModPixCorrect{ttId1}=bs_curve_interpo_Fun(tPits,NumDensePit(ttId1));
    end
end


function ScaleOriBranch=ScaleVesselBranch(OriBranch,TarBranch)
tLen=size(OriBranch,1);
tShape=OriBranch-repmat(OriBranch(1,:),tLen,1)+repmat(TarBranch(1,:),tLen,1);

tOriLen=norm(tShape(end,:)-tShape(1,:));
tTarLen=norm(TarBranch(end,:)-TarBranch(1,:));

tRatio=tTarLen/tOriLen;

ScaleOriBranch=tShape;
for i=2:tLen
    ScaleOriBranch(i,:)=ScaleOriBranch(1,:)+tRatio*(ScaleOriBranch(i,:)-ScaleOriBranch(1,:));
end
