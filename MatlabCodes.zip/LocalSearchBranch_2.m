function [MinPix,MinId,MinLig,tIntenM]=LocalSearchBranch_2(ConsidImg,BranchPit,FlagQuad,CentPit,tvTN,OutNum,OutLen)
% For locally adjust the leg direction
% FlagQuad--- Flag of quadrant
% Add more curve templates of the average shape

[nR,nC,~]=size(ConsidImg);

nCA=[20,10]; % The number of curve templates and rotation angles 

tTheta=pi/10; % Maximum rotation angle
%CurveTemp=ParaCurveTemplate(d,tTheta,n); % Curve templates
CurveTemp=ParaCurveTemplateMean(BranchPit,tvTN,FlagQuad,tTheta,nCA);
nCurv=length(CurveTemp);

Vtn=tvTN;  Vtn(1,:)=Vtn(1,:)/norm(Vtn(1,:));  Vtn(2,:)=Vtn(2,:)/norm(Vtn(2,:)); 

figure; imshow(ConsidImg);
hold on; plot(CentPit(:,1),CentPit(:,2),'ob');
tempPit=[CentPit;CentPit+30*Vtn(1,:)];
hold on; plot(tempPit(:,1),tempPit(:,2),'-*g');
tempPit=[CentPit;CentPit+30*Vtn(2,:)];
hold on; plot(tempPit(:,1),tempPit(:,2),'-*b');

tIntenM=1e10*ones(nCurv,1); MinLig=1e10; MinId=[]; MinPix=[]; 

% Make the same length, the same number of points 
for j=1:nCurv % For curvature of the curve
    CurveTemp{j}=bs_curve_interpo_Fun(CurveTemp{j},50);

    tDistVec=cumsum(sqrt(sum(abs(CurveTemp{j}(2:end,:)-CurveTemp{j}(1:end-1,:)).^2,2))); 
    tPos=find(tDistVec>OutLen);
    if ~isempty(tPos)
        CurveTemp{j}=CurveTemp{j}(1:tPos(1),:);
    end % if 
    tTempPit=bs_curve_interpo_Fun(CurveTemp{j},OutNum);

    tTestPix=round(tTempPit);
    tTestPix(:,1)=max(1,min(nC,tTestPix(:,1)));  tTestPix(:,2)=max(1,min(nR,tTestPix(:,2))); 

    hold on; plot(tTestPix(:,1),tTestPix(:,2),'-b');
    hold on; plot(tTestPix(:,1),tTestPix(:,2),'color',[1-j/nCurv,0,0]);

    tIntenM(j)=-sum(ConsidImg((tTestPix(:,1)-1)*nR+tTestPix(:,2))<1e-3);

    if tIntenM(j)<MinLig
        MinLig=tIntenM(j); MinId=[j]; MinPix=tTestPix;
    end % if 
end 

