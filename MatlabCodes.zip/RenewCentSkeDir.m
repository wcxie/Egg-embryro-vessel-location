%function CentCOEFF=RenewCentSkeDir(AbanPixelBranch,CentCOEFF)
% Renew central skeleton direction by filtering out the pixels with large
% intersection angles

LenAbanPixelBranch=length(AbanPixelBranch);

tSkeTangV=CentCOEFF(:,1)';  tSkeNormV=CentCOEFF(:,2)';

% Select the upmost and downmost pixel
MaxMin=[-1e10,1e10]; MaxMinId=[0,0;0,0];
for i=1:LenAbanPixelBranch
    tPits=AbanPixelBranch{i};
    tCoe=tPits/[tSkeTangV;tSkeNormV];
    [uMax,uMaxId]=max(tCoe(:,1)); [uMin,uMinId]=min(tCoe(:,1));
    if uMax>MaxMin(1)
        MaxMin(1)=uMax; MaxMinId(:,1)=[i;uMaxId];
    end
    
    if uMin<MaxMin(2)
        MaxMin(2)=uMin; MaxMinId(:,2)=[i;uMinId];
    end
end

tDownPix=AbanPixelBranch{MaxMinId(1,2)}(MaxMinId(2,2),:);
tUpPix=AbanPixelBranch{MaxMinId(1,1)}(MaxMinId(2,1),:);

% Renew the principal direction with the pixels tDownPix, tUpPix
tSkeTangV1=(tDownPix-tUpPix)/norm(tDownPix-tUpPix);

% Increase some pixels in the circle around tBranchPit
tBaseCircR=0.8*norm((CentFivePit(4,:)-CentFivePit(2,:))); 
tempNum=50;
tAng=[1:tempNum]'/tempNum*2*pi;
tCircPit=repmat(tBranchPit,tempNum,1)+tBaseCircR*[cos(tAng),sin(tAng)];
tempMask=poly2mask(tCircPit(:,1),tCircPit(:,2),nR,nC);

% Renew the adjacent pixels with small intersection angles w.r.t.
% tSkeTangV1
tFilterPix=zeros(1e4,2); tLenFilterPix=0;
tCritAngSkeTang=pi/4;
for i=1:LenAbanPixelBranch
    tPits=AbanPixelBranch{i}; LentPits=length(tPits);
    for j=1:LentPits-1
        teTestPix=tPits([j,j+1],:); 
        if ~tempMask(teTestPix(1,2),teTestPix(1,1))||~tempMask(teTestPix(2,2),teTestPix(2,1))
            continue;
        end
        teTestDir=(teTestPix(1,:)-teTestPix(2,:))/norm(teTestPix(1,:)-teTestPix(2,:));
        teAng=acos(abs(dot(teTestDir,tSkeTangV1)));
        if teAng<tCritAngSkeTang
            tFilterPix(tLenFilterPix+1:tLenFilterPix+2,:)=teTestPix;
            tLenFilterPix=tLenFilterPix+2;
        end
    end
end

tCritAngSkeTang1=pi/6;
for i=1:LenBranch
    tPits=PixelBranch{i}; LentPits=length(tPits);
    for j=1:LentPits-1
        teTestPix=tPits([j,j+1],:); 
        if ~tempMask(teTestPix(1,2),teTestPix(1,1))||~tempMask(teTestPix(2,2),teTestPix(2,1))
            continue;
        end
        teTestDir=(teTestPix(1,:)-teTestPix(2,:))/norm(teTestPix(1,:)-teTestPix(2,:));
        teAng=acos(abs(dot(teTestDir,tSkeTangV1)));
        if teAng<tCritAngSkeTang1
            tFilterPix(tLenFilterPix+1:tLenFilterPix+2,:)=teTestPix;
            tLenFilterPix=tLenFilterPix+2;
        end
    end
end

tFilterPix=tFilterPix(1:tLenFilterPix,:);

% Renew CentCOEFF
CentCOEFF = princomp(tFilterPix);
