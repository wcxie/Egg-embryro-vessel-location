function vt=b_spline_fit_fun(Curve,OutN)

m=size(Curve,1)-1;
PitDim=size(Curve,2);

%Curve=zeros(m+1,1);

nk=3; n=m+nk-1;

% Curve=load('spiral.txt');
%Curve=load('spiralu01.txt');

Eps=1e-9;
Alpha=1;d_scale=0.6;u_scale=1.5; Scale=0.9;
%Alpha denotes the descending velocity, d_scale denotes scale of the
%velocity to descend, u_scale denote the scale of the velocity to ascend.
% Scale record the velocity to descend when the conditions can not be
% satisfied.
%nc=30;
nc=max(3,min(10,ceil(m/2)));

M=zeros(m+1,nc);  % the coefficient matrix for solving control points.
Bias=zeros(size(Curve)); % record the error between the initial and the fitting points.

dEw=zeros(nc,1); % dEw record the derivative to c_w, dEu to {u_4,...,u_n}.
dEu=zeros(m-1,1);  % ignore the derivatives at two endpoints because the fitting error at endpoints are zero.
% the derivatives are computed from u_4.

snw=zeros(m+1,1);  % record intermediate sums.
snwd=zeros(m+1,PitDim);
sdnw=zeros(m-1,1);
sdnwd=zeros(m-1,PitDim);

dpu=zeros(m-1,PitDim); % the computation starts from u_4 to u_n.
dpw=zeros(nc,PitDim);

c_w=ones(nc,1);  %record the initial weight coefficient of the control points.
LD=zeros(nc,PitDim);  %record the control points {w_iLd_i}.

v_k=zeros(nc-nk-1,1);
v_k=[1:(nc-nk-1)]'/(nc-nk);  %record the nonzero terms of the knot vector.

v_kt=zeros(nc+1+nk,1);  % record the knot vector, nk+1 zeros, 1 for the last element.
v_kt((nk+2):nc,1)=v_k;
v_kt((nc+1):(nc+1+nk),1)=ones(nk+1,1);


% compute the initial parameterization of the initial data. 
mut=zeros(m+1,1);
    mut(1)=0;
    for i=2:(m+1)
        %mut(i)=mut(i-1)+sqrt((V(i,1)-V(i-1,1))^2+(V(i,2)-V(i-1,2))^2+(V(i,3)-V(i-1,3))^2);
        mut(i)=mut(i-1)+sqrt((Curve(i,:)-Curve(i-1,:))*(Curve(i,:)-Curve(i-1,:))');
    end
mut=mut/mut(m+1); 

lc_w=zeros(size(c_w)); % record the last weight coefficient and parameter values.
lmut=zeros(size(mut));

%belowing program is based on the assumption nk=3.

N_jk=zeros(m-1,nk+1);  % record the value of B spline which start from the parameter u_{nk+1}.
dN_jk=zeros(m-1,nk+1);  % record the derivatives of B spline to parameter u at parameters {u_{nk+1},...}.

i_p=zeros(m-1,1);  % record the right most position on the left side of the parameter values {t_i}.

%%%%%%%%%%%%%%%%%% begin the loop of the optimization for weights and parameters.
for gen=1:5

 i0=nk+1;  % i0 record the right most knot on the left side of parameter t.  
for pi=2:m  % note mut(1)=0=u_{nk},mut(m+1)=1=u_{n+1}
    % for every parameter value u, compute the value of  B spline and the
    % derivative of B spline the u.
    t=mut(pi);                            
    while (t>=v_kt(i0+1))
        i0=i0+1;
    end
    
    i_p(pi-1)=i0;
    
    % compute the values of B spline at the parameter {u_i}.
    Nb=zeros(nk+1,nk+1);   % the rows record the descending position, the columns record the ascending orders.
 
    Nb(1,1)=1;
        for k=2:(nk+1)
            Nb(1,k)=(t-v_kt(i0))/(v_kt(i0+k-1)-v_kt(i0))*Nb(1,k-1);
        end
        
        for r=2:(nk+1)
            for k=r:(nk+1)
                if (v_kt(i0-r+k)>v_kt(i0-r+1))
                   Nb(r,k)=(t-v_kt(i0-r+1))/(v_kt(i0-r+k)-v_kt(i0-r+1))*Nb(r,k-1)+(v_kt(i0-r+k+1)-t)/(v_kt(i0-r+k+1)-v_kt(i0-r+2))*Nb(r-1,k-1);
                else
                   Nb(r,k)=(v_kt(i0-r+k+1)-t)/(v_kt(i0-r+k+1)-v_kt(i0-r+2))*Nb(r-1,k-1);
                end % if v_kt
            end %for j
        end %for r

        for j=1:(nk+1)
            N_jk(pi-1,j)=Nb(nk+2-j,nk+1);
        end %for j
        
        % another form to compute dN.
        %
        dN=zeros(nk+1);  % the intermediate derivative for all orders {0,1,...,nk} at nonzero points.
        
            dN(1)=(k-1)/(v_kt(i0+k-1)-v_kt(i0))*Nb(1,k-1);

        
        for r=2:(nk+1)
                if (Nb(r,nk)>0)
                    dN(r)=nk/(v_kt(i0-r+nk+1)-v_kt(i0-r+1))*Nb(r,nk)+...
                            -nk/(v_kt(i0-r+nk+1+1)-v_kt(i0-r+2))*Nb(r-1,nk);
                else
                    dN(r)=-nk/(v_kt(i0-r+nk+1+1)-v_kt(i0-r+2))*Nb(r-1,nk);
                end 
        end % for r
        %}
       
        for j=1:(nk+1)
            dN_jk(pi-1,j)=dN(nk+2-j);
        end %for k
end  %for pi


% construct the coefficient matrix of the equations for solving control points.

M(1,1)=1/c_w(1);
M(m+1,nc)=1/c_w(nc);
%M(1,1)=1;
%M(m+1,nc)=1;
for i=2:m
    t1=i_p(i-1);
    t_s=N_jk(i-1,:)*c_w((t1-nk):t1,1);
    if (t_s>Eps)
       M(i,(t1-nk):t1)=N_jk(i-1,:)/t_s;
    end  % if t_s
end %for i

% solve the linear equations to derive the control points {w_iLd_i}.
% use svd factorization method.

clear UM SM VM

[UM,SM,VM]=svd(M'*M);
for i=1:nc
    if (abs(SM(i,i))<Eps)
        Flag=0;
        disp('Coefficient M is singular!');
        return; %jump out of loop (for i)
    else
        ISM(i,i)=1/SM(i,i);
    end  % if abs
end %for i

if (i==nc)
    Flag=1;
end % if i==nc


if (Flag)
   LD=VM*(ISM*(UM'*(M'*Curve)));
else 
    return;
end %if Flag



Bias=M*LD-Curve;
e_xyz=Bias'*Bias;
%E_new=(sqrt(e_xyz(1,1))+sqrt(e_xyz(2,2))+sqrt(e_xyz(3,3)))/3;
E_new=sum(sqrt(diag(e_xyz)))/length(diag(e_xyz));


snw(1)=c_w(1);
snwd(1,:)=LD(1,:);
snw(m+1)=c_w(nc);
snwd(m+1,:)=LD(nc,:);
for i=2:m
        t1=i_p(i-1);
        snw(i)=N_jk(i-1,:)*c_w((t1-nk):t1,1);
        snwd(i,:)=N_jk(i-1,:)*LD((t1-nk):t1,:);
        sdnw(i-1)=dN_jk(i-1,:)*c_w((t1-nk):t1,1);
        sdnwd(i-1,:)=dN_jk(i-1,:)*LD((t1-nk):t1,:);    
        dpu(i-1,:)=(snw(i)*sdnwd(i-1,:)-sdnw(i-1)*snwd(i,:))/snw(i)^2;
        dEu(i-1)=2*Bias(i,:)*(dpu(i-1,:))';
end %for i


dEw=zeros(size(c_w));
for r=1:nc
    for i=2:m   % start from parameter value u_4.
        t1=i_p(i-1);  % note t1>=4.
       
        if (t1>=r)&&(t1<=r+nk)
            dpw(r,:)=N_jk(i-1,r+nk+1-t1)*(LD(r,:)/c_w(r)*snw(i)-snwd(i,:))/snw(i)^2;
            dEw(r)=dEw(r)+2*Bias(i,:)*dpw(r,:)';
        end % if t1
       
    end %for i
end %for r

if (gen>1)
    if (E_new<=E_old)
        Alpha=Alpha*u_scale;
        lc_w=c_w;
        lmut=mut;
        E_old=E_new;
    else
        Alpha=Alpha*d_scale;
    end
else % gen=1
    lc_w=c_w;
    lmut=mut;
    E_old=E_new;
end % if gen

% scale Alpha to satisfy the conditions.
for i=1:nc
    while (lc_w(i)-Alpha*dEw(i)<=0)||(lc_w(i)-Alpha*dEw(i)>=3)
        Alpha=Scale*Alpha;
    end % while
end % for i

for i=2:m
    if (i==2)
        while ((lmut(i)-Alpha*dEu(i-1)<=0)||(lmut(i)-Alpha*dEu(i-1)>=lmut(i+1)-Alpha*dEu(i)))
              Alpha=Scale*Alpha;
        end % while 
    elseif (i==m)
        while ((lmut(i)-Alpha*dEu(i-1)<=lmut(i-1)-Alpha*dEu(i-2))||(lmut(i)-Alpha*dEu(i-1)>=1))
              Alpha=Scale*Alpha;
        end % while 
    else
       while ((lmut(i)-Alpha*dEu(i-1)<=lmut(i-1)-Alpha*dEu(i-2))||(lmut(i)-Alpha*dEu(i-1)>=lmut(i+1)-Alpha*dEu(i)))
             Alpha=Scale*Alpha;
       end % while 
    end % if i==1
    
    if (Alpha<1e-16)
        disp('The step is too small!');
        return;
    end % if Alpha
end %for i

c_w=lc_w-Alpha*dEw;
mut(2:m,1)=lmut(2:m,1)-Alpha*dEu;

% gen
 %E_old
end  %for gen
%%%%%%%%%%%%%% end the loop.


N=OutN-1;

vt=zeros(N+1,PitDim);  % record the fitting points.

i0=nk+1;
for i=1:(N+1)
    t=(i-1)/N;   
    if (t>=1)
        t=1-1e-8;
    end
    
    while (t>=v_kt(i0+1))
        i0=i0+1;
    end

    
    % compute the values of B spline at the parameter {u_i}.
    Nb=zeros(nk+1,nk+1);   % the rows record the descending position, the columns record the ascending orders.
 
    Nb(1,1)=1;
        for k=2:(nk+1)
            Nb(1,k)=(t-v_kt(i0))/(v_kt(i0+k-1)-v_kt(i0))*Nb(1,k-1);
        end
        
        for r=2:(nk+1)
            for k=r:(nk+1)
                if (v_kt(i0-r+k)>v_kt(i0-r+1))
                   Nb(r,k)=(t-v_kt(i0-r+1))/(v_kt(i0-r+k)-v_kt(i0-r+1))*Nb(r,k-1)+(v_kt(i0-r+k+1)-t)/(v_kt(i0-r+k+1)-v_kt(i0-r+2))*Nb(r-1,k-1);
                else
                   Nb(r,k)=(v_kt(i0-r+k+1)-t)/(v_kt(i0-r+k+1)-v_kt(i0-r+2))*Nb(r-1,k-1);
                end % if v_kt
            end %for j
        end %for r
        
        N_ik=zeros(nk+1,1);
        for j=1:(nk+1)
            N_ik(j)=Nb(nk+2-j,nk+1);
        end %for j
        
        sum_u=N_ik'*LD((i0-nk):i0,:);
        sum_d=N_ik'*c_w((i0-nk):i0,1);
        vt(i,:)=sum_u/sum_d;
end % for i


        

