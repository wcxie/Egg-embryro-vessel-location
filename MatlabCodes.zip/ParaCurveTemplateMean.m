function CurveTemp=ParaCurveTemplateMean(BranchPit,Vtn,FlagQuad,tTheta,nCA)
% Construct curve templates around the mean shape branches

CentPit=BranchPit(1,:);

n=nCA(1); tAn=nCA(2);

if FlagQuad==1
    RotAngDir=Vtn;
elseif FlagQuad==2
    RotAngDir=[Vtn(2,:);-Vtn(1,:)];
elseif FlagQuad==3
    RotAngDir=[-Vtn(1,:);-Vtn(2,:)];
else
    RotAngDir=[-Vtn(2,:);Vtn(1,:)];
end % 

tVecT=BranchPit(5,:)-BranchPit(1,:); tVecT=tVecT/norm(tVecT); tNormT=[tVecT(2),-tVecT(1)];
if dot(BranchPit(3,:)-BranchPit(1,:),tNormT)<0
    tNormT=-tNormT;
end 

% The distance from the intersection points to the line BranchPit([1,5],:)
DistPitLine=zeros(5,1);
DiscretePit=zeros(n,5,2);
ta=BranchPit(5,2)-BranchPit(1,2); tb=-(BranchPit(5,1)-BranchPit(1,1)); 
tc=(BranchPit(5,1)-BranchPit(1,1))*BranchPit(1,2)-BranchPit(1,1)*(BranchPit(5,2)-BranchPit(1,2));
for i=2:4
  DistPitLine(i)=abs(ta*BranchPit(i,1)+tb*BranchPit(i,2)+tc)/sqrt(ta*ta+tb*tb);  
  ttSeq=linspace(0,DistPitLine(i),n)';
  DiscretePit(:,i,:)=repmat(BranchPit(i,:),n,1)-[ttSeq,ttSeq].*repmat(tNormT,n,1);
end 
DiscretePit(:,1,:)=repmat(BranchPit(1,:),n,1);  DiscretePit(:,end,:)=repmat(BranchPit(end,:),n,1);

% The rotation angle region
%RotAngReg=zeros(2,1); 
tAngVec=zeros(3,1);
for i=1:3
    if i==1
        tDir=tVecT;
    elseif i==2
        tDir=RotAngDir(1,:);
    else
        tDir=RotAngDir(2,:);
    end % if 
    
    tAngVec(i)=acos(dot(tDir,Vtn(1,:))/(norm(tDir)*norm(Vtn(1,:))));
    if dot(tDir,Vtn(2,:))<0
        tAngVec(i)=2*pi-tAngVec(i);
    end 
end % for 
if tAngVec(3)<tAngVec(2)
    tAngVec(3)=2*pi;
end % if 
% RotAngReg(1)=tAngVec(2)-tAngVec(1);
% RotAngReg(2)=tAngVec(3)-tAngVec(1);

%tAn=10;
tBaseAng=acos(dot([1,0],Vtn(1,:))/(norm(Vtn(1,:))));
if Vtn(1,2)<0
    tBaseAng=2*pi-tBaseAng;
end 
tAngSequ=linspace(max(tAngVec(2),min(tAngVec(3),tAngVec(1)-tTheta)),max(tAngVec(2),min(tAngVec(3),tAngVec(1)+tTheta)),tAn)+tBaseAng;
tAngSequ=tAngSequ-tAngVec(1);

CurveTemp=cell(tAn*n,1);
for i=1:tAn
    tAng=tAngSequ(i);
    tLocRotM=[cos(tAng),sin(tAng);-sin(tAng),cos(tAng)];
    
    for j=1:n
        tCentPits=repmat(CentPit,5,1);
        CurveTemp{(i-1)*n+j}=tCentPits+(reshape(DiscretePit(j,:,:),5,2)-tCentPits)*tLocRotM;
    end 
end % for i

%save Temp.mat