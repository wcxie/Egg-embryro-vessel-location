%%
imgPepper_t=double(im1)/255;
[T1,Thresh] = edge(imgPepper_t,'canny');
TT = edge(imgPepper_t,'canny',Thresh+[-0.3,+0.3]);
%figure; imshow(TT);

[nR,nC,~]=size(bwim1);

tSearchPit=[];
SnC=20;
for i=1:SnC
    iC=round(nC*i/(SnC+1));  tSearchWid=round(nR/3);
    tFlag=0;  r=1;
    while ~tFlag && r<=tSearchWid
        if TT(r,iC)
            tFlag=1;  tSearchPit=[tSearchPit;iC,r];  break; 
        end % if 
        r=r+1;
    end % while 
    
    tFlag=0;  r=1;
    while ~tFlag && r<=tSearchWid
        if TT(nR-r,iC)
            tFlag=1; tSearchPit=[tSearchPit;iC,nR-r];  break; 
        end % if 
        r=r+1;
    end % while 
end % for i
%hold on; plot(tSearchPit(:,1),tSearchPit(:,2),'*r');

[zb, ab, bb, alphab] = fitellipse(tSearchPit', 'linear');
tBndPit=transpose(EllipseFitPit(zb, ab, bb, alphab, 18));
tBndPit(:,1)=max(4,min(nC-3,tBndPit(:,1)));  tBndPit(:,2)=max(4,min(nR-3,tBndPit(:,2)));

%hold on; plot(tBndPit(:,1),tBndPit(:,2),'-ob');

%%
%
tMask=poly2mask(tBndPit(:,1),tBndPit(:,2),nR,nC);
%se = strel('disk',round(min(nR,nC)/5));
se = strel('disk',round(min(nR,nC)/10));
erodedBM = imerode(tMask,se);
erodedBMtt=imerode(tMask,strel('disk',round(min(nR,nC)/5)));
%figure; imshow(erodedBM);

%%
%
% Select the region with the darkest color
ConsidImg=1-(bwim1==0).*erodedBM;
%figure; imshow(ConsidImg);

%
[tX,tY]=find(ConsidImg==0);  tInInd=(tY(:)-1)*nR+tX(:);

LenPit=length(tX);
MaxRadius=zeros(LenPit,1);
for i=1:LenPit
    for r=5:50
%         t=linspace(0,2*pi,10)'; tPit=[tY(i)+r*cos(t),tX(i)+r*sin(t)];
%         tMask=poly2mask(tPit(:,1),tPit(:,2),nR,nC);
%         tImg=tMask.*erodedBM;
        
        if ~isempty(find(ConsidImg(tX(i)-r:tX(i)+r,tY(i)-r:tY(i)+r)))
        %if ~isempty(find(tImg))
            MaxRadius(i)=r;
            break; 
        end % if 
    end % for 
end % for i

tInIndValid=find(erodedBMtt);
[tSortV,tSortId]=sort(MaxRadius,'descend');
for i=1:length(tSortId)
    if ismember(tInInd(tSortId(i)),tInIndValid)
        tMaxId=tSortId(i);  tBenchDist=MaxRadius(tMaxId);
        break;
    end % if 
end % if 
%tBenchDist=MaxRadius(tMaxId);

%
%figure; imshow(ConsidImg);
%hold on; plot(tY(tMaxId),tX(tMaxId),'*b');

%% Circle and abanon the main body
rCirc=2*tBenchDist;

t=linspace(0,2*pi,30)'; tPit=repmat([tY(tMaxId),tX(tMaxId)],length(t),1)+rCirc*[cos(t),sin(t)];
tMask=poly2mask(tPit(:,1),tPit(:,2),nR,nC);
ConsidImgOld=ConsidImg;
ConsidImg(find(tMask))=1;

%% Estimate the branches of the embryo with ring structure
tMult1=[6,7,-pi/4,pi/4]; % The radius region and section angles
SearchD=round(2*tBenchDist);
%SearchD=round(2*tBenchDist);
MaxRotAng=2*pi; MaxRotNum=45; 
tIntenM=1e10*ones(2*SearchD+1,MaxRotNum);
for tNumTest=1:MaxRotNum
    tTestAng=tNumTest*MaxRotAng/MaxRotNum;
    
    tRotMax=[cos(tTestAng),-sin(tTestAng);sin(tTestAng),cos(tTestAng)];
    %tVecT=(tRotMax*tBaseVecT')'; tVecN=(tRotMax*tBaseVecN')';
    tVecT=[cos(tTestAng),sin(tTestAng)]; tVecN=[sin(tTestAng),-cos(tTestAng)];  % W.r.t. the main shape
    
    %tCircPit=[tY(tMaxId),tX(tMaxId)]+rCirc*[cos(tTestAng),sin(tTestAng)];
    
    tVirtCent=[tY(tMaxId),tX(tMaxId)]-(tMult1(1)-2)*tBenchDist*[cos(tTestAng),sin(tTestAng)]; % virtual circle center

    tSectionAng=linspace(tTestAng+tMult1(3),tTestAng+tMult1(4),30)';
    tCornerPit1=repmat(tVirtCent,length(tSectionAng),1)+tBenchDist*tMult1(1)*[cos(tSectionAng),sin(tSectionAng)];
    tCornerPit2=repmat(tVirtCent,length(tSectionAng),1)+tBenchDist*tMult1(2)*[cos(tSectionAng),sin(tSectionAng)];
    tCornerPit=[tCornerPit1;tCornerPit2(end:-1:1,:)];
    
    tSectionAng1=linspace(tTestAng+tMult1(3),tTestAng+0,30/2)';
    tCornerPit11=repmat(tVirtCent,length(tSectionAng1),1)+tBenchDist*tMult1(1)*[cos(tSectionAng1),sin(tSectionAng1)];
    tCornerPit21=repmat(tVirtCent,length(tSectionAng1),1)+tBenchDist*tMult1(2)*[cos(tSectionAng1),sin(tSectionAng1)];
    tCornerPit1=[tCornerPit11;tCornerPit21(end:-1:1,:)];
    
    %tCornerPit=repmat(tCircPit,4,1)+tBenchDist*tMult1*[tVecN;tVecT];

    tBaseRectMask=poly2mask(tCornerPit(:,1),tCornerPit(:,2),nR,nC); % The main branch
    [tBaseRectX,tBaseRectY]=find(tBaseRectMask);
    tBaseRectPit=[tBaseRectY(:),tBaseRectX(:)];
    
    tBaseRectMask1=poly2mask(tCornerPit1(:,1),tCornerPit1(:,2),nR,nC); % For branch symmetry
    [tBaseRectX1,tBaseRectY1]=find(tBaseRectMask1);
    tBaseRectPit1=[tBaseRectY1(:),tBaseRectX1(:)];
    
    tCircPit=[tY(tMaxId),tX(tMaxId)]+rCirc*[cos(tTestAng),sin(tTestAng)];
    tCornerPit2=[tCircPit;tCircPit;[tY(tMaxId),tX(tMaxId)]-0.5*tBenchDist*tVecT;[tY(tMaxId),tX(tMaxId)]-0.5*tBenchDist*tVecT]+...
             tBenchDist*repmat([-0.5;0.5;0.5;-0.5],1,2).*repmat(tVecN,4,1);
    tBaseRectMask2=poly2mask(tCornerPit2(:,1),tCornerPit2(:,2),nR,nC);  % The binary mask of the main body
    [tBaseRectX2,tBaseRectY2]=find(tBaseRectMask2);
    tBaseRectPit2=[tBaseRectY2(:),tBaseRectX2(:)];
    
    for i=[-SearchD:SearchD]    
        tPitRect=round(tBaseRectPit+i*repmat(tVecT,size(tBaseRectPit,1),1));
        tIntenM(i+SearchD+1,tNumTest)=sum(ConsidImg((tPitRect(:,1)-1)*nR+tPitRect(:,2)));
        
        % New added! Symmetry term
        tPitRect1=round(tBaseRectPit1+i*repmat(tVecT,size(tBaseRectPit1,1),1));
        tIntenM(i+SearchD+1,tNumTest)=tIntenM(i+SearchD+1,tNumTest)+...
            abs(2*sum(ConsidImg((tPitRect1(:,1)-1)*nR+tPitRect1(:,2)))-tIntenM(i+SearchD+1,tNumTest)); 
        
        % New added! Lighting term of the above main body
        tPitRect2=round(tBaseRectPit2+i*repmat(tVecT,size(tBaseRectPit2,1),1));
        tIntenM(i+SearchD+1,tNumTest)=tIntenM(i+SearchD+1,tNumTest)+...
            sum(ConsidImgOld((tPitRect2(:,1)-1)*nR+tPitRect2(:,2)));
    end % for i
end % for tNumTest

[tMinM,ttId2d]=min(tIntenM(:)); [tMinMId,tMinMIdA]=ind2sub(size(tIntenM),ttId2d);

tTestAng=tMinMIdA*MaxRotAng/MaxRotNum;    
%tRotMax=[cos(tTestAng),-sin(tTestAng);sin(tTestAng),cos(tTestAng)];
tVecT=[cos(tTestAng),sin(tTestAng)]; tVecN=[sin(tTestAng),-cos(tTestAng)];  % W.r.t. the main shape

tVirtCent=[tY(tMaxId),tX(tMaxId)]-(tMult1(1)-2)*tBenchDist*[cos(tTestAng),sin(tTestAng)]; % virtual circle center

tSectionAng=linspace(tTestAng+tMult1(3),tTestAng+tMult1(4),30)';
tCornerPit1=repmat(tVirtCent,length(tSectionAng),1)+tBenchDist*tMult1(1)*[cos(tSectionAng),sin(tSectionAng)];
tCornerPit2=repmat(tVirtCent,length(tSectionAng),1)+tBenchDist*tMult1(2)*[cos(tSectionAng),sin(tSectionAng)];
tCornerPit=[tCornerPit1;tCornerPit2(end:-1:1,:)];
    
tCircPit=[tY(tMaxId),tX(tMaxId)]+rCirc*[cos(tTestAng),sin(tTestAng)];
%tCornerPit=repmat(tCircPit,4,1)+tBenchDist*tMult1*[tVecN;tVecT];
tBaseRectMask=poly2mask(tCornerPit(:,1),tCornerPit(:,2),nR,nC);
[tBaseRectX,tBaseRectY]=find(tBaseRectMask);
tBaseRectPit=[tBaseRectY(:),tBaseRectX(:)];

tPit=tCircPit+(tMinMId-SearchD-1)*tVecT;
tPitRect=round(tBaseRectPit+(tMinMId-SearchD-1)*repmat(tVecT,size(tBaseRectPit,1),1));


tCornerPit2=[tCircPit;tCircPit;[tY(tMaxId),tX(tMaxId)]-0.5*tBenchDist*tVecT;[tY(tMaxId),tX(tMaxId)]-0.5*tBenchDist*tVecT]+...
             tBenchDist*repmat([-0.5;0.5;0.5;-0.5],1,2).*repmat(tVecN,4,1);
tBaseRectMask2=poly2mask(tCornerPit2(:,1),tCornerPit2(:,2),nR,nC);  % The binary mask of the main body
[tBaseRectX2,tBaseRectY2]=find(tBaseRectMask2);
tBaseRectPit2=[tBaseRectY2(:),tBaseRectX2(:)];
tPitRect2=round(tBaseRectPit2+(tMinMId-SearchD-1)*repmat(tVecT,size(tBaseRectPit2,1),1));


tBranchVecT=tVecT;  tBranchVecN=tVecN;  tBranchPitRect=tPitRect;
tBranchPit=tPit;


%% Obtain the principal direction by maximizing the gray rectangle
ConsidImg=ConsidImgOld;

tBaseVecT=tBranchVecT; tBaseVecN=tBranchVecN;
tMult1=[-0.1,-0.5;4,-0.5;4,0.5;-0.1,0.5]; % The width and height of searched rectangle
SearchD=round(tBenchDist);
MaxRotAng=pi/6; MaxRotNum=6; 
tIntenM=zeros(2*SearchD+1,2*MaxRotNum+1);
for tNumTest=-MaxRotNum:MaxRotNum
    tTestAng=tNumTest*MaxRotAng/MaxRotNum;
    
    tRotMax=[cos(tTestAng),-sin(tTestAng);sin(tTestAng),cos(tTestAng)];
    tVecT=(tRotMax*tBaseVecT')'; tVecN=(tRotMax*tBaseVecN')';
    
    %tCornerPit=repmat([tY(tMaxId),tX(tMaxId)],4,1)+tBenchDist*tMult1*[tVecT;tVecN];
    tCornerPit=repmat(tBranchPit,4,1)-tBenchDist*tMult1*[tVecT;tVecN];
    tBaseRectMask=poly2mask(tCornerPit(:,1),tCornerPit(:,2),nR,nC);
    [tBaseRectX,tBaseRectY]=find(tBaseRectMask);
    tBaseRectPit=[tBaseRectY(:),tBaseRectX(:)];
    
    for i=-SearchD:SearchD    
        tPitRect=round(tBaseRectPit+i*repmat(tVecN,size(tBaseRectPit,1),1));
        tIntenM(i+SearchD+1,tNumTest+MaxRotNum+1)=sum(ConsidImg((tPitRect(:,1)-1)*nR+tPitRect(:,2)));
    end % for i
end % for tNumTest

[tMinM,ttId2d]=min(tIntenM(:)); [tMinMId,tMinMIdA]=ind2sub(size(tIntenM),ttId2d);

tTestAng=(tMinMIdA-MaxRotNum-1)*MaxRotAng/MaxRotNum;    
tRotMax=[cos(tTestAng),-sin(tTestAng);sin(tTestAng),cos(tTestAng)];
tVecT=(tRotMax*tBaseVecT')'; tVecN=(tRotMax*tBaseVecN')';

%tCornerPit=repmat([tY(tMaxId),tX(tMaxId)],4,1)+tBenchDist*tMult1*[tVecT;tVecN];
tCornerPit=repmat(tBranchPit,4,1)-tBenchDist*tMult1*[tVecT;tVecN];
tBaseRectMask=poly2mask(tCornerPit(:,1),tCornerPit(:,2),nR,nC);
[tBaseRectX,tBaseRectY]=find(tBaseRectMask);
tBaseRectPit=[tBaseRectY(:),tBaseRectX(:)];

tPit=[tY(tMaxId),tX(tMaxId)]+(tMinMId-SearchD-1)*tVecN; % Modified central point
tPitRect=round(tBaseRectPit+(tMinMId-SearchD-1)*repmat(tVecN,size(tBaseRectPit,1),1)); % Rectangle points

tMainVecT=tVecT; tMainVecN=tVecN; tMainPit=tPit; tMainPitRect=tPitRect; tMainCornerPit=tCornerPit;


%
%% Accurate information of the main body
% Slightly move tMainPit
tMult2=tBenchDist*[-1,-1;1,-1;1,1;-1,1]; % The width and height of searched rectangle
MaxRotAng=pi/8; MaxRotNum=3;

% Move tMainPit to be the center
tModMainPit=tMainPit;  tTryPit=tModMainPit; tW=round(2*tBenchDist);  % tH=round(0.5*tBenchDist);
tMinLig=1e10; tPits=cell(2,1); tMeanLig=round(tBenchDist);
for i=-tBenchDist:tBenchDist
    tTryPit=tMainPit+i*tBaseVecN;
    for k=1:2
        tPits{k}=repmat(tTryPit,tW,1)+(2*k-3)*diag([1:tW])*repmat(tBaseVecN,tW,1)-repmat(tBaseVecT,tW,1);
        tPits{k}=[tPits{k};repmat(tTryPit,tW,1)+(2*k-3)*diag([1:tW])*repmat(tBaseVecN,tW,1)];
        tPits{k}=[tPits{k};repmat(tTryPit,tW,1)+(2*k-3)*diag([1:tW])*repmat(tBaseVecN,tW,1)+repmat(tBaseVecT,tW,1)];
        tPits{k}=round(tPits{k});
    end % 
    tLig1=sum(ConsidImg((tPits{1}(:,1)-1)*nR+tPits{1}(:,2))<1)/3;
    tLig2=sum(ConsidImg((tPits{2}(:,1)-1)*nR+tPits{2}(:,2))<1)/3;
    if abs(tLig1-tLig2)<tMinLig
        tModMainPit=tTryPit; tMinLig=abs(tLig1-tLig2); tMeanLig=mean([tLig1,tLig2]);
    end % if 
end % if 

 % Obtain the fourth point
tVec=tBaseVecT;
if dot(tVec,tBranchPit-tModMainPit)>0
    tVec=-tVec;
end % if

CentFivePit=zeros(5,2);

CentFivePit(5,:)=tModMainPit;  
tePit=tBranchPit+0.8*tBenchDist*tVec; 
if dot(tVec,tModMainPit-tePit)<0.2*tBenchDist
    CentFivePit(1,:)=tBranchPit;
else
    CentFivePit(1,:)=tePit;
end % if 
CentFivePit(2,:)=tModMainPit-tMeanLig*tBaseVecN; CentFivePit(4,:)=tModMainPit+tMeanLig*tBaseVecN; 

tSearchD=round(3*tBenchDist);

tPits=cell(2,3);
for i=1:tSearchD
    tTryPit=tModMainPit+i*tVec;
    for k=1:2
        for j=3:-1:1
            tPits{k,j}=repmat(tTryPit,tW,1)+(2*k-3)*diag([1:tW])*repmat(tBaseVecN,tW,1)+(j-2)*repmat(tVec,tW,1);
            tPits{k,j}=round(tPits{k,j});
        end % for 
    end % 
    
    ttPitD=[tPits{1,1};tPits{2,1}];  ttPitU=[tPits{1,3};tPits{2,3}];
    
    tId=find(ConsidImg((ttPitD(:,1)-1)*nR+ttPitD(:,2))<1);
    if length(find(ConsidImg((ttPitU(tId,1)-1)*nR+ttPitU(tId,2))))>0.2*length(tId)
        CentFivePit(3,:)=mean(ttPitD(tId,:));
        break;
    end % if 
end % 

if norm(CentFivePit(3,:)-CentFivePit(5,:))>3*norm(CentFivePit(1,:)-CentFivePit(5,:))
    CentFivePit(3,:)=2*CentFivePit(5,:)-CentFivePit(1,:);
end % if 

tBaseNorm3=[0,0,1];
load s0.mat
if det([CentFivePit(2,:)-CentFivePit(1,:),0;CentFivePit(4,:)-CentFivePit(1,:),0;tBaseNorm3])*det([s0(2,:)-s0(1,:),0;s0(4,:)-s0(1,:),0;tBaseNorm3])<0
    CentFivePit([2,4],:)=CentFivePit([4,2],:);
end % if 

%% Locally perturb the points CentFivePit such that the length of principal
% direction rectangle contains the maximum black pixels
tOptDir=ModCentFivePit(CentFivePit,ConsidImg,pi/5); tLongestOptDir=tOptDir;
OldCentFivePit=CentFivePit;

CentFivePit(1,:)=CentFivePit(5,:)+norm(CentFivePit(1,:)-CentFivePit(5,:))*tOptDir;
CentFivePit(3,:)=CentFivePit(5,:)-norm(CentFivePit(3,:)-CentFivePit(5,:))*tOptDir;
tOptDirNorm=[tOptDir(2),-tOptDir(1)];
if dot(tOptDirNorm,CentFivePit(4,:)-CentFivePit(2,:))<0
    tOptDirNorm=-tOptDirNorm;
end
CentFivePit(2,:)=CentFivePit(5,:)-norm(CentFivePit(2,:)-CentFivePit(5,:))*tOptDirNorm;
CentFivePit(4,:)=CentFivePit(5,:)+norm(CentFivePit(4,:)-CentFivePit(5,:))*tOptDirNorm;


%% Obtain the initial frame of the embryo structure
% EmbLineAAM;
BaseBranchLen=3.1890e+003;
EnlargeFlag=1;

while EnlargeFlag==1||EnlargeFlag==2
    [d,Z,transform]=procrustes(CentFivePit,s0(1:5,:));
    EstShape=transform.b*s0*transform.T+repmat(mean(transform.c),size(s0,1),1);
    %figure; imshow(ConsidImg);
    tIndId=1;

    tBaseDist=0;
    for i=1:7
        tId1=[5*(i-1)+2:5*i]; tId2=[5*(i-1)+1:5*i-1];
        tBaseDist=tBaseDist+sum(sqrt(sum(abs(EstShape(tId1,:)-EstShape(tId2,:)).^2,2)));
    end

    if tBaseDist>=0.85*BaseBranchLen-eps
        EnlargeFlag=0;
    else % Enlarge the points CentFivePit
        EnlargeRatio=0.85*BaseBranchLen/tBaseDist;
        for i=1:4
            CentFivePit(i,:)=CentFivePit(5,:)+EnlargeRatio*(CentFivePit(i,:)-CentFivePit(5,:));
        end % if 
        EnlargeFlag=EnlargeFlag+1;
    end % if 
end % if 
