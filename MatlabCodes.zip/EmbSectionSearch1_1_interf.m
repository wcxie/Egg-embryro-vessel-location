% EmbSectionSearch1_1
% Locally search the embryo branches

warning off

se = strel('disk',3);

%EmbInitLine1;

CellEstShape=cell(100,1);
CellOptimizedPix=cell(100,4);
QuadCurvCell=cell(4,1);
CellCellModPix=cell(100,1);
CellCellSmoothModPix=cell(100,1);
CellConsidImg=cell(100,1);

for Num=14 %  Num=14 is useless
%for Num=1:100
    %EmbInitLine3;
    
    [nR,nC,~]=size(ConsidImg);
    
    %close all
    CentFivePit=EstShape(1:5,:);

    tBranchPit=CentFivePit(1,:);

    Vtn=zeros(2,2); % The principal and normal directions of the branch
    Vtn(1,:)=CentFivePit(4,:)-CentFivePit(2,:); Vtn(1,:)=Vtn(1,:)/norm(Vtn(1,:));
    Vtn(2,:)=[Vtn(1,2),-Vtn(1,1)];
    if dot(Vtn(2,:),CentFivePit(3,:)-CentFivePit(1,:))<0
        Vtn(2,:)=-Vtn(2,:);
    end % if 
    
    CellConsidImg{Num}=ConsidImg;
    teConsidImg=ConsidImg;
    
    tvT=(CentFivePit(4,:)-CentFivePit(2,:))/2;  tvN=2*(CentFivePit(3,:)-CentFivePit(1,:))/2;
    tCornerPit=repmat(CentFivePit(5,:),4,1)+[-tvT-tvN;-tvT+tvN;tvT+tvN;tvT-tvN];
    teConsidImg(find(poly2mask(tCornerPit(:,1),tCornerPit(:,2),size(teConsidImg,1),size(teConsidImg,2))))=1;
    
    % Get rid of pixels far from the center
    tDistMax=-1e10;
    for kk=1:6
        tDistMax=max(tDistMax,norm(EstShape(kk*5+3,:)-tBranchPit));
    end %
    tt=linspace(0,2*pi,30)'; tCircleMaskPit=repmat(tBranchPit,30,1)+tDistMax*[cos(tt),sin(tt)];
    teConsidImg(find(1-poly2mask(tCircleMaskPit(:,1),tCircleMaskPit(:,2),size(teConsidImg,1),size(teConsidImg,2))))=1;
    teConsidImgOld=teConsidImg;  % teConsidImg=teConsidImgOld;
    
    % Get rid of pixels on main branch and far from its center
    tvTnorm=tvT/norm(tvT); tAngPit=[7*pi/4,9*pi/4,3*pi/4,5*pi/4]; 
    for i=1:2
        if i==1 
            tttFlag=1;
        else
            tttFlag=-1;
        end % if 
        tt=linspace(tAngPit(2*i-1),tAngPit(2*i),30);
        tCornerPit=zeros(length(tt),2);
        for j=1:length(tt)
            tCornerPit(j,:)=tBranchPit+tDistMax*tvTnorm*[cos(tt(j)),sin(tt(j));-sin(tt(j)),cos(tt(j))];
        end
        tCornerPit=[tCornerPit;tBranchPit+tttFlag*0.9*tDistMax*tvTnorm];
        teConsidImg(find(poly2mask(tCornerPit(:,1),tCornerPit(:,2),size(teConsidImg,1),size(teConsidImg,2))))=1;
    end
    
    % Get rid of the pixels on main body and main branch direction 
    tvT=(CentFivePit(4,:)-CentFivePit(2,:))/2;  tvN=2*(CentFivePit(3,:)-CentFivePit(1,:))/2; tLenN=norm(tvN);
    %tCornerPit=repmat(CentFivePit(5,:),4,1)+[-1.5*tvT-3*tvN;-1.5*tvT+3*tvN;1.5*tvT+3*tvN;1.5*tvT-3*tvN];
    tCornerPit=repmat(CentFivePit(5,:),4,1)+[-1.5*tvT-3*tLongestOptDir*tLenN;-1.5*tvT+3*tLongestOptDir*tLenN;...
                               1.5*tvT+3*tLongestOptDir*tLenN;1.5*tvT-3*tLongestOptDir*tLenN];
    %tCornerPit=repmat(CentFivePit(5,:),4,1)+[-tvT-3*tvN;-tvT+3*tvN;tvT+3*tvN;tvT-3*tvN];
    tCornerPit(:,1)=max(1,min(nC,tCornerPit(:,1))); tCornerPit(:,2)=max(1,min(nR,tCornerPit(:,2))); 
    teConsidImg(find(poly2mask(tCornerPit(:,1),tCornerPit(:,2),size(teConsidImg,1),size(teConsidImg,2))))=1;
    
    
    % Get rid of region segmentation far from the center
    BW = im2bw(teConsidImg, graythresh(teConsidImg));
    [B,L] = bwboundaries(BW);
    
    for k = 1:length(B)
        tBndPit=B{k}(:,[2,1]);
        if ~isempty(find(tBndPit(:,1)==1)) continue;  end
        
        %if sum(teConsidImg((tBndPit(:,1)-1)*nR+tBndPit(:,2))) continue; end
        
        tBias=tBndPit-repmat(tBranchPit,size(tBndPit,1),1);
        tDist=sqrt(sum(abs(tBias).^2,2));
        if length(find(tDist>3*tDistMax/4))>3*length(tDist)/4 
            teBinM=poly2mask(tBndPit(:,1),tBndPit(:,2),nR,nC);
            ttId=find(teBinM);
            
            %if sum(teConsidImg(ttId))>length(find(teBinM))/2 continue; end
            
            %teBinM=imdilate(teBinM,se);
            teConsidImg(ttId)=1;
        end
    end
    
    MinLigVec=1e10*ones(4,1);  tIntenMVec=cell(4,1);
    % The curve templates of quadratic curve
    %BranchPit=EstShape((3-1)*5+1:3*5,:);
    BranchPit=EstShape((6-1)*5+1:6*5,:);
    CurveDist=zeros(4,1);
    for kk=1:4
        [MinPix,QuadCurv,MinId,MinLig,tIntenM]=LocalSearchBranch(teConsidImg,BranchPit,Vtn,kk,tBranchPit);
        CellOptimizedPix{Num,kk}=MinPix;
        CurveDist(kk)=sum(sqrt(sum(abs(MinPix(2:end,:)-MinPix(1:end-1,:)).^2,2)));
        QuadCurvCell{kk}=QuadCurv;
        MinLigVec(kk)=MinLig;  tIntenMVec{kk}=tIntenM;
    end % for kk
    CellOptimizedPixOld=CellOptimizedPix(Num,:);
    
    
    %% The curve templates of implicit shapes
    CellOptimizedPixNew=CellOptimizedPix(Num,:);
    for kk=1:2
        [tMinPix,tMinId,tMinLig,ttIntenM]=LocalSearchBranch_1(teConsidImg,kk,tBranchPit,[tvT;tvN],size(CellOptimizedPix{Num,kk},1),CurveDist(kk));
        CellOptimizedPixNew{kk}=tMinPix;
        if tMinLig<MinLigVec(kk)
            %disp('kk1='); kk
            MinId=tMinId; MinLigVec(kk)=tMinLig; tIntenMVec{kk}=ttIntenM;
            CellOptimizedPix{Num,kk}=tMinPix;
        end % if 
    end
    
    % Restrict the template points below the searched 1-2th branches
    tvTt=CellOptimizedPix{Num,1}(60,:)-CellOptimizedPix{Num,2}(60,:); tvTt=tvTt/norm(tvTt);  tvNt=[tvTt(2),-tvTt(1)];
    tvT=tvTt*norm(tvT);
    DistFlag=[dot(tvNt,CellOptimizedPix{Num,1}(end,:)-CellOptimizedPix{Num,1}(1,:))>0,...
              dot(tvNt,CellOptimizedPix{Num,2}(end,:)-CellOptimizedPix{Num,2}(1,:))>0];
    tPreInf={tvNt,DistFlag,CellOptimizedPix{Num,1}(1,:)};

    for kk=3:4
        % Be down of 2nd, 1st horizontal lines 
        [tMinPix,tMinId,tMinLig,ttIntenM]=LocalSearchBranch_1(teConsidImg,kk,tBranchPit,[tvT;tvN],size(CellOptimizedPix{Num,kk},1),CurveDist(kk),tPreInf);
        CellOptimizedPixNew{kk}=tMinPix;
        if tMinLig<MinLigVec(kk)
            %disp('kk1='); kk
            MinId=tMinId; MinLigVec(kk)=tMinLig; tIntenMVec{kk}=ttIntenM;
            CellOptimizedPix{Num,kk}=tMinPix;
        end % if 
    end
    
    CellOptimizedPixOld=CellOptimizedPix;  
    
%     %% Renew the other (3-4th) branches with mean shape and 1-2th branches
%     CellOptimizedPix(Num,3:4)=Renew3_4Branch(CentFivePit,CellOptimizedPix(Num,1:2),s0);
    
    % The curve templates around the mean shape
    CellOptimizedPixNewN=CellOptimizedPix(Num,:);
    tSelId=[6,4,3,7];
    for kk=[]
        tShap=EstShape((tSelId(kk)-1)*5+1:tSelId(kk)*5,:); tShap(1,:)=EstShape(1,:);
        [tMinPix,tMinId,tMinLig,ttIntenM]=LocalSearchBranch_2(teConsidImg,tShap,kk,tBranchPit,...
                                                        [tvT;tvN],size(CellOptimizedPix{Num,kk},1),CurveDist(kk));
        CellOptimizedPixNewN{kk}=tMinPix;
        if tMinLig<MinLigVec(kk)
            %disp('kk2='); kk
            MinLigVec(kk)=tMinLig; tIntenMVec{kk}=ttIntenM;
            CellOptimizedPix{Num,kk}=tMinPix;
        end % if 
    end
    
    %[~,CellModPix]=FindQuadCurveCrossPit(QuadCurvCell,tBranchPit);
    
    [~,CellModPix]=FindCurveCrossPit1(CellOptimizedPix(Num,:),tBranchPit);
    
    CellEstShape{Num}=EstShape;
    
    CellCellModPix{Num}=CellModPix;
    
end % for Num
