%% Main script of open snake model for embryo vessel detection
%% [1] Weicheng Xie, Jinming Duan, Linlin Shen, Yuexiang Li, Meng Yang and Guojun Lin
%% "A novel open snake model based on global guidance field for embryo vessel location" 
%
% Unless stated, code written by Weicheng Xie(wcxie@szu.edu.cn)
% Part of the code developed based on 
% Jinmin Duan (psxjd3@nottingham.ac.uk) for TVG-L1 smoothness,
% Guanglei Xiong (xgl99@mails.tsinghua.edu.cn) for self adaptive thresholding,
% Richard Brown (R.G.Brown@massey.ac.nz) for ellipse fitting,
% Many thanks for these!
% Special thanks to Joan Alabort-i-Medina
%
% Code released as is for research purposes only
% Feel free to modify/distribute but please cite [1]

1. AllOperatMain.m is the main function of the codes.

2. For AAM training and learning, the preceding 40 images are used as the training dataset (i.e. A1.jpg-A51.jpg),
the other 32 images are used as the testing dataset (i.e. A52.jpg-A88.jpg). 
The codes of AAM is codes by Georgios (Yorgos) Tzimiropoulos, which can be downloaded from :
http://www.mathworks.com/matlabcentral/fileexchange/44651-active-appearance-models--aams-


