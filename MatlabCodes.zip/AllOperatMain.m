%% Main script of open snake model for embryo vessel detection
%% [1] Weicheng Xie, Jinming Duan, Linlin Shen, Yuexiang Li, Meng Yang and Guojun Lin
%% "A novel open snake model based on global guidance field for embryo vessel location" 
%
% Unless stated, code written by Weicheng Xie(wcxie@szu.edu.cn)
% Part of the code developed based on 
% Jinmin Duan (psxjd3@nottingham.ac.uk) for TVG-L1 smoothness,
% Guanglei Xiong (xgl99@mails.tsinghua.edu.cn) for self adaptive thresholding,
% Richard Brown (R.G.Brown@massey.ac.nz) for ellipse fitting,
% Many thanks for these!
% Special thanks to Joan Alabort-i-Medina
%
% Code released as is for research purposes only
% Feel free to modify/distribute but please cite [1]

close all; clc
% 1. %% Select images and the patch the spots
ImgFilePath='.\InitialGrayFig\';  % The initial gray images

GoodId=[5,12,14,23,24,30,33,35,39,44,47,48,50,52,55,58,68,72,74,79,80,83,86,87];  % The indices of good dataset
FairId=[2,3,4,11,17,22,28,34,41,49,51,56,57,61,62,64,65,69,70,75,76,77,78,84];
PoorId=[1,6,13,18,21,25,26,27,29,32,37,38,40,42,43,46,59,60,63,66,73,81,85,88];

GroundTruthPath='.\ManualExtract\';  % The ground truth shapes

ImgSmoothFilePath='.\SmoothInitialGrayFig\';  % The smoothed images

FlagReSmooth=1; % Denote whether re-smoothing operation is employed

CellModPixAll=cell(100,2);
MeanErrors=zeros(100,1);
%for NumImgId=1:100
for NumImgId=79
    close all
    
    if ~exist(strcat(ImgFilePath,'A',num2str(NumImgId),'.jpg'),'file')
        continue;
    end  % if
    
     imageSN=imread(strcat(ImgFilePath,'A',num2str(NumImgId),'.jpg'));
     if size(imageSN,3)>1 imageSN=rgb2gray(imageSN);  end
     
     if FlagReSmooth
        % Detect and patch the spots
        SpotDetectPatch;

        % 2. %% Smoothness
        dualTVL1(imageSN);

        % 3. %% Self adaptive threshold
        u=load('Temp.mat','u'); % Temp.mat is obtained in 'dualTVL1.m'
        SmoothImage=u(1).u;
    else
        SmoothImage=imread(strcat(ImgSmoothFilePath,'SmoothA',num2str(NumImgId),'.png'));
    end
    
    bw=adaptivethreshold(SmoothImage,200,0.05,0);
    
    imshow(bw);  %axis off
    
    % 4. %% Initial structure
    im1=SmoothImage;
    bwim1=bw;
    EmbInitLine3_interf;
    
    imshow(ConsidImg);
    tIndId=1;
    for j=1:7
        hold on; plot(EstShape(5*(j-1)+1:5*j,1,tIndId),EstShape(5*(j-1)+1:5*j,2,tIndId),'*r');
        hold on; line(EstShape(5*(j-1)+1:5*j,1,tIndId),EstShape(5*(j-1)+1:5*j,2,tIndId));
        for i=1:5
            hold on; text(EstShape(5*(j-1)+i,1,tIndId),EstShape(5*(j-1)+i,2,tIndId),num2str(i));
        end % for i
    end % for
    
    % 5. %% Optimized structure
    EmbSectionSearch1_1_interf;
    
    imshow(imageSN);
    
    load s0.mat s0 % The average ground truth shape
    [CellModPix,tAbnId]=AbnormShapCorrect(s0,CentFivePit,CellModPix);  % Modify the optimized shape if it is abnormal
    
    OutPit=cell(5,1);
    smoothCentFivePit=bs_curve_interpo_Fun(CentFivePit,20);
    hold on; plot(smoothCentFivePit(:,1),smoothCentFivePit(:,2),'-or');
    OutPit{1}=smoothCentFivePit;
    for kk=1:4
        smoothCellModPix=bs_curve_interpo_Fun(CellModPix{kk}(1:10:end,:),20);
        %smoothCellModPix=b_spline_fit_fun(CellModPix{kk},20);
        if ismember(kk,tAbnId)
            hold on; plot(smoothCellModPix(:,1),smoothCellModPix(:,2),'-ob');
        else
            hold on; plot(smoothCellModPix(:,1),smoothCellModPix(:,2),'-or');
        end
        %hold on; plot(CellModPix{kk}(:,1),CellModPix{kk}(:,2),'-or');
        %hold on; text(smoothCellModPix(end,1),smoothCellModPix(end,2),num2str(kk));
        
        OutPit{kk+1}=smoothCellModPix;
    end % for kk
    
    gcf=figure;
    hold on; imshow(imageSN);
    smoothCentFivePit=bs_curve_interpo_Fun(CentFivePit,20);
    hold on; plot(smoothCentFivePit(:,1),smoothCentFivePit(:,2),'-or');
    for kk=1:4
        smoothCellModPix=bs_curve_interpo_Fun(CellModPix{kk}(1:5:end,:),20);
        hold on; plot(smoothCellModPix(:,1),smoothCellModPix(:,2),'-or');
    end % for kk
    %print(gcf,'-dpng',strcat('DetectFig','.png'));
    close(gcf);
    
    % 6. %% Optimization with snake model
    IniImage=bw;
    im1=SmoothImage;
    CentFivePitOri=EstShape(1:5,:);
    CellModPix=OutPit; CellModPix=CellModPix(2:end);
    for kk=1:4
        CellModPix{kk}=bs_curve_interpo_Fun(CellModPix{kk},100);
    end
    
    % Perform optimization with snake model
    DFSaDistLenImage1_1_inferf;
    
    CellModPix=OutPitSnake(2:end);
    
    imshow(imageSN);
    
    CentFivePit=CentFivePitOri;
    
    tAbnId=[];
    load s0.mat s0
    [CellModPix,tAbnId]=AbnormShapCorrect(s0,CentFivePit,CellModPix);  % Modify the optimized shape if it is abnormal
    
    OutPit=cell(5,1);
    smoothCentFivePit=bs_curve_interpo_Fun(CentFivePit,20);
    hold on; plot(smoothCentFivePit(:,1),smoothCentFivePit(:,2),'-or');
    OutPit{1}=smoothCentFivePit;
    for kk=1:4
        smoothCellModPix=bs_curve_interpo_Fun(CellModPix{kk}(1:10:end,:),20);
        if ismember(kk,tAbnId)
            hold on; plot(smoothCellModPix(:,1),smoothCellModPix(:,2),'-ob');
        else
            hold on; plot(smoothCellModPix(:,1),smoothCellModPix(:,2),'-or');
        end
        %hold on; plot(CellModPix{kk}(:,1),CellModPix{kk}(:,2),'-or');
        %hold on; text(smoothCellModPix(end,1),smoothCellModPix(end,2),num2str(kk));
        
        OutPit{kk+1}=smoothCellModPix;
    end % for kk
    
    gcf=figure;
    hold on; imshow(imageSN);
    smoothCentFivePit=bs_curve_interpo_Fun(CentFivePit,20);
    hold on; plot(smoothCentFivePit(:,1),smoothCentFivePit(:,2),'-or');
    for kk=1:4
        smoothCellModPix=bs_curve_interpo_Fun(CellModPix{kk}(1:10:end,:),20);
        hold on; plot(smoothCellModPix(:,1),smoothCellModPix(:,2),'-or');
    end % for kk
    %close(gcf);
    %}
    
    % Obtain the shapes of ground truth and optimization
    tShape=load(strcat(GroundTruthPath,'\A',num2str(NumImgId),'_0.mat'));
    
    GroundTruthS=zeros(35,2); SmoothGroundTruthS=cell(7,1);
    for i=1:7
        tGroundTruthS=tShape.CellLinePit{i}(1:5,:);
        tSmoothGroundTruthS=bs_curve_interpo_Fun(tGroundTruthS,100);
        hold on; plot(tSmoothGroundTruthS(:,1), tSmoothGroundTruthS(:,2),'-*b','MarkerSize',2);
        SmoothGroundTruthS{i}=tSmoothGroundTruthS;
    end 
    
    tCellDensePit=cell(4,1);
    for kk=1:4
        smoothCellModPix=bs_curve_interpo_Fun(CellModPix{kk}(1:10:end,:),100);
        tCellDensePit{kk}=smoothCellModPix;
        hold on; plot(smoothCellModPix(:,1),smoothCellModPix(:,2),'-or','MarkerSize',2);
        hold on; text(smoothCellModPix(end,1),smoothCellModPix(end,2),num2str(kk),'fontsize',14,'color','r');
    end % for kk
    
    % Compute the bias distance
    CellMinDist=zeros(100,4);
     tCorId=[6,4,3,7];
    for i=1:100
        for kk=1:4
            CellMinDist(i,kk)=min(sqrt(sum(abs(repmat(tCellDensePit{kk}(i,:),100,1)-SmoothGroundTruthS{tCorId(kk)}).^2,2))); % The minimum distance
        end
    end
    
    MinMaxXY=[1e10,-1e10,1e10,-1e10]; % Record the minimums and maximums of the x,y coordinates of all the branches
    for kk=1:4
        MinMaxXY(1)=min(MinMaxXY(1),min(tCellDensePit{kk}(:,1)));  MinMaxXY(2)=max(MinMaxXY(2),max(tCellDensePit{kk}(:,1)));
        MinMaxXY(3)=min(MinMaxXY(3),min(tCellDensePit{kk}(:,2)));  MinMaxXY(4)=max(MinMaxXY(4),max(tCellDensePit{kk}(:,2)));
    end
    
    CellMinDist=CellMinDist/sqrt((MinMaxXY(2)-MinMaxXY(1))^2+(MinMaxXY(4)-MinMaxXY(3))^2); % The normalized distances
    MeanErrors(NumImgId)=mean(CellMinDist(:));
    
    
    CellModPixAll{NumImgId}=CellModPix;
end %  for NumImgId