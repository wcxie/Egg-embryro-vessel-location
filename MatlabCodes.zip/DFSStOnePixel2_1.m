function [NumPixelBranch,PixelBranch]=DFSStOnePixel2_1(StP,FlagVisited,NumAdjP,AdjP,CritLenAband)
% Return all the pixel branches starting from StP, non recursive form
% StP---The starting searching pixel with NumAdjP(StP(1),StP(2))=1
% NumPixelBranch---Denote the number of pixels on each branch
% PixelBranch---Record all the pixels on each branch, in cell form

% More branches are detected compared with DFSStOnePixel2

[nR,nC,~]=size(FlagVisited);

tSum=0; % The number of the found branches

FlagVisited(StP(2),StP(1))=1; % Renew the label of current pixel
S(1,1:2)=StP;

NumPixelBranch=zeros(1e2,1);  % Record the number of branch pixels
PixelBranch=cell(1e2,1); % Record the branch of pixels

IdReachBranch=ones(size(FlagVisited));  % Record which branch the pixel reaches

OriStP=StP;

Top=1;
while Top>0
    StP=S(Top,1:2); % The starting pixel
    FlagVisited(StP(2),StP(1))=FlagVisited(StP(2),StP(1))+1;
    
    tNum=NumAdjP(StP(2),StP(1));  % The number of adjacent skeleton pixels
    tPit=AdjP{StP(2),StP(1)}; % The adjacent skeleton pixels
    
    FlagFound=0;
    
    %disp('1:'); IdReachBranch(OriStP(2),OriStP(1))
    
    % for i=IdReachBranch(StP(2),StP(1)):tNum
    %if IdReachBranch(StP(2),StP(1))<=tNum
        i=IdReachBranch(StP(2),StP(1));
        ttPit=tPit(i,:); % One adjacent pixel
        while FlagVisited(ttPit(2),ttPit(1))&&i<tNum
            IdReachBranch(StP(2),StP(1))=IdReachBranch(StP(2),StP(1))+1;
            i=IdReachBranch(StP(2),StP(1));
            ttPit=tPit(i,:); % One adjacent pixel
        end % 
        
        if ~FlagVisited(ttPit(2),ttPit(1))  % One valid adjacent pixel is found
            FlagFound=1;
            
            FlagVisited(ttPit(2),ttPit(1))=FlagVisited(ttPit(2),ttPit(1))+1; % The number of visited
            IdReachBranch(ttPit(2),ttPit(1))=IdReachBranch(ttPit(2),ttPit(1))+1; % The number of branches
            Top=Top+1;
            S(Top,1:2)=ttPit;
            %break; % Jump out of for i
            
            % Renew the sequence of the adjacent points of StP
            tPitsId=(tPit(:,1)-1)*nR+tPit(:,2); % The indices of all the adjacent points
            [~,ttId]=sort(FlagVisited(tPitsId),'descend'); % Non-visited pixels are ranked behind
            AdjP{StP(2),StP(1)}=tPit(ttId,:);
            
            tPitsId=(AdjP{ttPit(2),ttPit(1)}(:,1)-1)*nR+AdjP{ttPit(2),ttPit(1)}(:,2); % The indices of all the adjacent points
            [~,ttId]=sort(FlagVisited(tPitsId),'descend'); % Non-visited pixels are ranked behind
            AdjP{ttPit(2),ttPit(1)}=AdjP{ttPit(2),ttPit(1)}(ttId,:);
        end % if ~FlagVisited
    
    if ~FlagFound||NumAdjP(S(Top,2),S(Top,1))==1 
        
        FlagOverlap=0;
        
        if size(S,1)<CritLenAband
            FlagOverlap=1;
        end % if 
        
        if (tSum==0||FlagOverlap==0)&&size(S,1)>=CritLenAband&&NumAdjP(S(Top,2),S(Top,1))==1 
            tSum=tSum+1;
            NumPixelBranch(tSum,1)=size(S,1);  % Record the number of branch pixels
            PixelBranch{tSum,1}=S; % Record the branch of pixels
        end % if 
  
        % Return to the knot which is not full
        FlagTry=1; % Record whether the knot is found
        while FlagTry&&Top>1
            Top=Top-1;
            if Top>1
                ttPit=S(Top,:);
                if IdReachBranch(ttPit(2),ttPit(1))<NumAdjP(ttPit(2),ttPit(1)) % A knot which is not full is found
                    FlagTry=0;
                    IdReachBranch(ttPit(2),ttPit(1))=IdReachBranch(ttPit(2),ttPit(1))+1; % Consider the next branch
                end
            end
        end
        
        if Top==1 % Return the topmost pixel
            NumPixelBranch=NumPixelBranch(1:tSum);
            PixelBranch=PixelBranch(1:tSum);
            %disp('OK2');
            %save Temp.mat
            return;
        end
        
        S=S(1:Top,:); % Shorten the branch
    end % if ~FlagFound    
    
    %disp('3:'); IdReachBranch(OriStP(2),OriStP(1))
end % if Top
NumPixelBranch=NumPixelBranch(1:tSum);
PixelBranch=PixelBranch(1:tSum);
