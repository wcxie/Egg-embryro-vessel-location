% Segment the up and down branches
% RenewSegTTup_down;

% AbanCentSkeleton;  % CentCOEFF
 
%%
tMoveDownDist=norm((CentFivePit(4,:)-CentFivePit(2,:))/2);  
if dot(CentCOEFF(:,1)',CentFivePit(3,:)-CentFivePit(1,:))<0
    CentCOEFF(:,1)=-CentCOEFF(:,1);
end
tPosPit=tBranchPit-tMoveDownDist*CentCOEFF(:,1)'+tMoveDownDist*CentCOEFF(:,2)'; 
tNegPit=tBranchPit-tMoveDownDist*CentCOEFF(:,1)'-tMoveDownDist*CentCOEFF(:,2)'; 


%%
% Construct the segmenatation line linking the points tPosPit and tNegPit
teCentPit=mean([tPosPit;tNegPit]);
teLen=floor(10*norm(tPosPit-tNegPit));
teLen1=floor(6*norm(tPosPit-tNegPit));
tTangVec=(tPosPit-tNegPit)/norm(tPosPit-tNegPit);

%figure; imshow(TT);
for i=-teLen:teLen
    ttPit=max(1,round(teCentPit+i/teLen*teLen1*tTangVec)); ttPit=min(ttPit,[nC,nR]);  %hold on; plot(ttPit(1),ttPit(2),'.g');
    TT(ttPit(2),ttPit(1))=0;
end
%hold on; plot(tPosPit(:,1),tPosPit(:,2),'or');
%hold on; plot(tNegPit(:,1),tNegPit(:,2),'or');
