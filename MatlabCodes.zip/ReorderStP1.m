%function y=ReorderStP1()
% Reorder the starting pixels such that the farest pixels rank in the front
% In this way, skeleton line searched by DFS can be longer

% Different from ReorderStP that the PixelBranch is not used for reordering

%% Obtain pixels groups for sequence the pixels AStP
IdAStP=(AStP(:,1)-1)*nR+AStP(:,2); % All starting pixels

%tRemBranchId=[1:LenBranch]; % Remainder indices of branches
%tAbanPixId=[];
%tBranchGroup=cell(LenBranch,1);
%tPixGroup=cell(LenBranch,1);
tPixGroupId=zeros(1e5,2);
tSum=0; tSum1=0;
% tSum: the number of groups 
% tSum1: the number of pixels

teFlagVisited=1-TT; 
tempId=find(teFlagVisited(:)==0);  tP=zeros(1,2);
while ~isempty(tempId)
    tSum1Old=tSum1;
    tSum=tSum+1;
    [tP(2),tP(1)]=ind2sub([nR,nC],tempId(1));
    
    teFlagVisited(tP(2),tP(1))=1;
    % Obtain all the pixels linking the pixel tP
    tempP=tP;  LentempP=1;
    while LentempP
        ntempP=[];  nLentempP=0;  % New LentempP, tempP
        
        for k=1:LentempP % Find adjacent pixels
            tPit=repmat(tempP(k,:),8,1)+BaseDir;
            tId=find(teFlagVisited((tPit(:,1)-1)*nR+tPit(:,2))==0);
            
            teFlagVisited((tPit(tId,1)-1)*nR+tPit(tId,2))=1; % To avoid overlapped points during the latter iteration
            
            nLentempP=nLentempP+length(tId);
            ntempP=[ntempP;tPit(tId,:)];
        end
        
        LentempP=nLentempP;   tempP=ntempP;
        if LentempP
            teFlagVisited((tempP(:,1)-1)*nR+tempP(:,2))=1;
        end
        
        tId=intersect(IdAStP,(tempP(:,1)-1)*nR+tempP(:,2)); LentId=length(tId); % Find the intersecting starting pixels
        if LentId
            tSum1=tSum1+LentId;
            tPixGroupId(tSum1-LentId+1:tSum1,1)=tId';
            tPixGroupId(tSum1-LentId+1:tSum1,2)=tSum*ones(LentId,1);
        end
        
        %hold on; plot(tempP(:,1),tempP(:,2),'<b');
    end
    
    if ~isempty(intersect(IdAStP,(tP(:,1)-1)*nR+tP(:,2)))
        tSum1=tSum1+1;
        tPixGroupId(tSum1,1)=(tP(:,1)-1)*nR+tP(:,2);
        tPixGroupId(tSum1,2)=tSum;
    end
    
    tempId=find(teFlagVisited(:)==0);  % Un-visited pixels
    if tSum1Old==tSum1 tSum=tSum-1; end
end
tPixGroupId=tPixGroupId(1:tSum1,:);

% Group the starting pixels
LenAStP=size(AStP,1);
IdAStP=(AStP(:,1)-1)*nR+AStP(:,2);
IdGroupAStP=zeros(LenAStP,1); % Which group the pixel belongs to
for i=1:LenAStP
    IdGroupAStP(i)=tPixGroupId(find(tPixGroupId(:,1)==IdAStP(i)),2);
end

tBranchPit=CentFivePit(1,:);
Vtn=zeros(2,2);  Vtn(1,:)=CentFivePit(4,:)-CentFivePit(2,:); Vtn(1,:)=Vtn(1,:)/norm(Vtn(1,:)); Vtn(2,:)=[Vtn(1,2),-Vtn(1,1)];

tGroupAStPId=cell(tSum,1);
UpMostStP=zeros(tSum,2);  % Record the upmost starting pixel
UpMostStPId=zeros(tSum,1);
for i=1:tSum
    tGroupAStPId{i}=find(IdGroupAStP==i);
    
    tStP=AStP(tGroupAStPId{i},:); LentStP=size(tStP,1);
    % Sort the starting pixels

    tSignDist=sum(repmat(Vtn(2,:),LentStP,1).*(tStP-repmat(tBranchPit,LentStP,1)),2);
    %[~,tIdMin]=min(tSignDist);  
    [~,tIdMax]=max(tSignDist); 

    %UpMostStP(2*i-1,:)=AStP(tGroupAStPId{i}(tIdMin,:),:);    
    UpMostStPId(i)=tGroupAStPId{i}(tIdMax,:);
    UpMostStP(i,:)=AStP(UpMostStPId(i),:);  
end

tStPSeq=[UpMostStPId;setdiff([1:LenAStP]',UpMostStPId)];
OriAStP=AStP;
AStP=AStP(tStPSeq,:);