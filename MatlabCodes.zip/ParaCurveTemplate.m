function CurveTemp=ParaCurveTemplate(d,tTheta,n)
% Construct curve templates (implicit curve templates)
% d: The distance from the origin
% tTheta: The angle with the horizontal direction
% n: The number of template curves

n1=2*n; n2=6*n;

t1=linspace(0,d,n1)';
tPit1=[zeros(n1,1),t1];

t2=linspace(1,2*d,n2)';

tIniPit2=[t2,zeros(n2,1)];
tLocRotM=[cos(tTheta),sin(tTheta);-sin(tTheta),cos(tTheta)];
tPit2=tIniPit2*tLocRotM;
tPit2=tPit2+[zeros(n2,1),d*ones(n2,1)];

OutN=50; % The number of output points

CurveTemp=cell(n,1);

T1=ceil(n1/4); S2=n2-floor(n2/4);
Step1=n1/2/n;  Step2=n2/2/n; 
for i=1:n
    tT1=T1+floor(i*Step1)-1; tS2=S2-floor(i*Step2)+1;
    ttP=[tPit1(1:tT1,:);tPit2(tS2+1:end,:)];
    CurveTemp{i}=b_spline_fit_fun(ttP,OutN);
end % for i

if abs(abs(tTheta)-pi/10)<1e-6
%save Temp.mat
end