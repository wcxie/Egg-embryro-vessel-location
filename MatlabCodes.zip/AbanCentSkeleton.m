%function y=AbanCentSkeleton()
% Abandon the central skeleton segments for local optimization

% ContinEdge;

%%
tBranchPit=EstShape(1,:);

% Find the nearest pixel on skeleton to tBranchPit
LenBranch=length(NumPixelBranch);
tMinDist=1e8; tMinId=[0,0];
tPitsId=zeros(1e3,LenBranch);
for i=1:LenBranch
    tPits=PixelBranch{i}; tLenPits=length(tPits);
    tPitsId(1:tLenPits,i)=(tPits(:,1)-1)*nR+tPits(:,2);
    [teMinD,teMinId]=min(sum(abs(repmat(tBranchPit,tLenPits,1)-tPits),2));
    if teMinD<tMinDist
        tMinDist=teMinD;  tMinId=[teMinId,i];
    end
end

% Find out all the skeleton lines linking the nearest pixel
[tr,tc]=find(tPitsId==tPitsId(tMinId(1),tMinId(2)));
LinkFlag=1;
tAbanPixId=[];
for ii=1:length(tc)
    i=tc(ii);  tAbanPixId=union(tAbanPixId,tPitsId(find(tPitsId(:,i)>0),i));
end % for i
tRemBranchId=setdiff([1:LenBranch],tc);

while LinkFlag
    LinkFlag=0;
    for i=tRemBranchId
        if ~isempty(intersect(tPitsId(:,i),tAbanPixId))
            LinkFlag=1;
            tAbanPixId=union(tAbanPixId,tPitsId(find(tPitsId(:,i)>0),i));
            tRemBranchId=setdiff(tRemBranchId,i);
        end
    end
end

%%
% Abandon the skeleton parts on downside of the heart

% Form the principal direction by the abandoned points
tAbanBranchId=setdiff([1:LenBranch],tRemBranchId);
tAbanPixel=[];
for ii=1:length(tAbanBranchId)
    i=tAbanBranchId(ii);
    tAbanPixel=[tAbanPixel;PixelBranch{i}];
    TT((PixelBranch{i}(:,1)-1)*nR+PixelBranch{i}(:,2))=0;
end
COEFF = princomp(tAbanPixel);

tPit=[tBranchPit;tBranchPit+10*COEFF(:,1)';tBranchPit+10*COEFF(:,2)'];


CentCOEFF=COEFF; % Used in RenewSegTTup_down;

CentCOEFFori=CentCOEFF;
AbanPixelBranch=PixelBranch(tAbanBranchId);
RenewCentSkeDir;  % Renew CentCOEFF

%% Abandon the skeleton pixels in the central rectangle region
tRatioLen=3;
tCutHoriz=norm(CentFivePit(4,:)-CentFivePit(2,:))/tRatioLen; tCutVert=tCutHoriz*10;
tCornerPit=max(1,repmat(tBranchPit,4,1)+[-tCutVert,-tCutHoriz;tCutVert,-tCutHoriz;tCutVert,tCutHoriz;-tCutVert,tCutHoriz;]*[CentCOEFF(:,1)';CentCOEFF(:,2)']);
tCornerPit(:,1)=min(nC,tCornerPit(:,1));  tCornerPit(:,2)=min(nR,tCornerPit(:,2));
tempMask=poly2mask(tCornerPit(:,1),tCornerPit(:,2),nR,nC);

TT(find(tempMask))=0;
