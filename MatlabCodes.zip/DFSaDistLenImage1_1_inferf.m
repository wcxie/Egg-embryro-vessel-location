% function y=DFSaDistLenImage1_1_inferf()
% i.e. search the continuous edge and construct distance/length image

%close all
%clear all
warning off
tic
%% Obtain the image information

DiskFlag='e';
ShrinkR=5; % The shrink ratio, SnakeContour2.m

%load EmbryoResult11_20.mat CellCellModPix CellEstShape CellConsidImg  % Locate the initial position by curve templates
%load EmbryoResult12_09.mat CellCellModPix CellEstShape CellConsidImg  % Locate the initial position by curve templates
load GroundTruthShape.mat GroundTruthShape % Contain all the ground truth shapes

OptDensePit=cell(100,4);  % The optimized points
ImgLenDistCell=cell(100,1);  % Record all the length*distance images

%SelDetectId=[5,30,55,14,48,62,44,63,85];
% Adopt the skeleton image for searching
%for Num=[21,35,82]
for Num=14
    %%
    %im1=imread(strcat(DiskFlag,':\R2009b\work\LineDetector\SmoothInitialGrayFig\SmoothA',num2str(Num),'.png'));
    bwim1=adaptivethreshold(im1,200,0.05,0);
    
    imgPepper_t=double(im1)/255;
    [T1,Thresh] = edge(imgPepper_t,'canny');
    TT = edge(imgPepper_t,'canny',Thresh+[-0.3,+0.3]);
    
    [nR,nC,~]=size(bwim1);
    
    tSearchPit=[];
    SnC=20;
    for i=1:SnC
        iC=round(nC*i/(SnC+1));  tSearchWid=round(nR/3);
        tFlag=0;  r=1;
        while ~tFlag && r<=tSearchWid
            if TT(r,iC)
                tFlag=1;  tSearchPit=[tSearchPit;iC,r];  break;
            end % if
            r=r+1;
        end % while
        
        tFlag=0;  r=1;
        while ~tFlag && r<=tSearchWid
            if TT(nR-r,iC)
                tFlag=1; tSearchPit=[tSearchPit;iC,nR-r];  break;
            end % if
            r=r+1;
        end % while
    end % for i
    
    [zb, ab, bb, alphab] = fitellipse(tSearchPit', 'linear');
    tBndPit=transpose(EllipseFitPit(zb, ab, bb, alphab, 18));
    tBndPit(:,1)=max(4,min(nC-3,tBndPit(:,1)));  tBndPit(:,2)=max(4,min(nR-3,tBndPit(:,2)));
    
    tMask=poly2mask(tBndPit(:,1),tBndPit(:,2),nR,nC);
    se = strel('disk',round(min(nR,nC)/15));
    erodedBM = imerode(tMask,se);
    erodedBMtt=imerode(tMask,strel('disk',round(min(nR,nC)/5)));
    
    
    %%
    %EstShape=CellEstShape{Num};
    CentFivePit=EstShape(1:5,:);
    
    OrinR=size(IniImage,1); OrinC=size(IniImage,2); % Perform shrinkage
    nR=floor(OrinR/ShrinkR);  nC=floor(OrinC/ShrinkR);
    rowR=OrinR/nR;  colR=OrinC/nC;
    IniImage=imresize(IniImage,[nR,nC]);
    %tRndPit=[tRndPit(:,1)/colR,tRndPit(:,2)/rowR];
    
    EstShape=[EstShape(:,1)/colR,EstShape(:,2)/rowR];
    
    image = 1-bwmorph(~IniImage,'skel',Inf);
    %figure; imshow(image)
    
    [nR,nC,~]=size(image);
    
    %tMask=poly2mask(tRndPit(:,1),tRndPit(:,2),nR,nC);
    tMask=imresize(erodedBM,[nR,nC]);
    
    image(find(1-tMask))=1;
    %figure; imshow(image)
    
    TT=1-image; % The skeleton pixels are with bright lighting
    
    tImage=(1-TT).*(TT>image)+image.*(TT<=image);
    %figure; imshow(tImage);
    
    OriTT=TT; OritImage=tImage; % Record the original image information
    
    %% Conduct DFS search, 1. branch segmentation, DFS search,
    %% 2. abandon central skeleton, DFS, 3. segment the up-down branches,DFS
    for FlagBeforeSeg=1:4 % Record whether the central pixels have been separated
        FlagVisited=1-tMask;  % Record whether the edge pixel is visited, 1---visited
        [t1,t2]=find(FlagVisited==0);
        ConsPixel=[t2,t1];
        LenConsPixel=size(ConsPixel,1);
        
        BaseDir=[1,0;1,-1;0,-1;-1,-1]; % Base directions
        BaseDir=[BaseDir;-BaseDir];
        
        NumAdjP=zeros(size(TT)); % The number of adjacent pixels w.r.t. each pixel
        AdjP=cell(size(TT));  % Record all the pixels
        
        for i1=1:LenConsPixel
            CurP=ConsPixel(i1,:);
            
            AdjCurP=repmat(CurP,8,1)+BaseDir; % Search around 8 adjacent points
            for kk=1:8
                if TT(AdjCurP(kk,2),AdjCurP(kk,1))
                    tt=AdjCurP(kk,:);
                    if tMask(tt(2),tt(1))
                        NumAdjP(CurP(2),CurP(1))=NumAdjP(CurP(2),CurP(1))+1;
                        AdjP{CurP(2),CurP(1)}(NumAdjP(CurP(2),CurP(1)),1:2)=tt;
                    end % if tt
                end % if TT
            end % for kk
        end % for i1
        
        AStP=zeros(1e4,2);  % The pixels with only one adjacent edge pixel
        LenAStP=0;
        for i1=1:LenConsPixel
            tPit=AdjP{ConsPixel(i1,2),ConsPixel(i1,1)};
            if (NumAdjP(ConsPixel(i1,2),ConsPixel(i1,1))==1||(NumAdjP(ConsPixel(i1,2),ConsPixel(i1,1))==2&&sum(abs(tPit(1,:)-tPit(2,:)))==1))&&TT(ConsPixel(i1,2),ConsPixel(i1,1))==1
                LenAStP=LenAStP+1;
                AStP(LenAStP,:)=ConsPixel(i1,:);
            end % if NumAdjP
        end % for ii
        AStP=AStP(1:LenAStP,:);
        
        %return;
        ReorderStP1;
        
        % Perform DFS
        CritLenAband=8; % Critical length for abandoning the short wrinkles
        
        NumAllBranch=0;
        NumPixelBranch=zeros(LenAStP*10,1);
        PixelBranch=cell(LenAStP*10,1);
        SelStP=zeros(LenAStP*10,2);  NumSelStP=0; % Selected starting pixel of each continuous edge
        
       %%
        %for kk=15;
        for kk=1:LenAStP
            StP=AStP(kk,:);
            
            if FlagVisited(StP(2),StP(1))
                %if FlagVisited(StP(1),StP(2))
                continue; % Goto the next kk directly
            end % if FlagVisited
            
            set(0,'RecursionLimit',1e4);
            
            %[tNumPixelBranch,tPixelBranch]=DFSStOnePixel2(StP,FlagVisited,NumAdjP,AdjP,CritLenAband);
            [tNumPixelBranch,tPixelBranch]=DFSStOnePixel2_1(StP,FlagVisited,NumAdjP,AdjP,CritLenAband);
            
            % Set another side point of the wrinkle line as visited
            for i=1:length(tNumPixelBranch)
                for j=1:tNumPixelBranch(i)
                    tPit=tPixelBranch{i}(j,:);
                    FlagVisited(tPit(2),tPit(1))=1;
                end % for j
            end % for i
            
            tId=find(tNumPixelBranch>=CritLenAband); % Get rid of some short wrinkles
            tNumPixelBranch=tNumPixelBranch(tId);
            tPixelBranch=tPixelBranch(tId);
            
            if isempty(tId)
                continue;
            end % if
            
            NumSelStP=NumSelStP+1;
            SelStP(NumSelStP,:)=StP; % The selected starting pixels
            
            tLen=length(tNumPixelBranch);
            
            NumPixelBranch(NumAllBranch+1:NumAllBranch+tLen)=tNumPixelBranch;
            PixelBranch(NumAllBranch+1:NumAllBranch+tLen)=tPixelBranch;
            NumAllBranch=NumAllBranch+tLen;
        end % for kk
        NumPixelBranch=NumPixelBranch(1:NumAllBranch);
        PixelBranch=PixelBranch(1:NumAllBranch);
        SelStP=SelStP(1:NumSelStP,:);
        
        % Obtain renewed SelStP such that the searched skeleton lines by DFS can be longer
        %ReorderStP;  % Select the upmost starting pixel in the front
        
        
        % Iteration for obtaining the orientation of the embryo
        if FlagBeforeSeg==1 % Separate the central skeleton
            RenewSegmentTT;
            %return;
            tImage=1-TT;
        end
        
        if FlagBeforeSeg==2 % Abandon central skeletons
            %return;
            OriTT=TT;
            AbanCentSkeleton;
            %tImage=1-TT;
            TT=OriTT;  % The central skeleton lines are not abandoned
        end
        
        %return;
        
        if FlagBeforeSeg==3 % Segment the up and down vessel branches
            %return;
            %RenewSegTTup_down;
            RenewSegTTup_down1;
            tImage=1-TT;
        end
        
        %return;
    end % FlagBeforeSeg
    
    
    %%
    LenBranch=length(NumPixelBranch);

    %% Obtain some information about the branches
    NumBranchVec=zeros(LenBranch,1);
    for i=1:LenBranch
        NumBranchVec(i)=length(PixelBranch{i});
    end
    
    [~,IdSort]=sort(NumBranchVec,'descend');
    LenBranch=length(NumPixelBranch);
    
    %% DistLenImage
    %load QuadrantInfor3.mat % CellQuadrantId tvT tvN, by  SnakeContour2_1.m
    
    tvT=(CentFivePit(4,:)-CentFivePit(2,:))/2;  tvN=2*(CentFivePit(3,:)-CentFivePit(1,:))/2;
    
    if dot(CentCOEFF(:,1)',tvN)<0  CentCOEFF(:,1)=-CentCOEFF(:,1);  end
    if dot(CentCOEFF(:,2)',tvT)<0  CentCOEFF(:,2)=-CentCOEFF(:,2);  end
    tvN=norm(tvN)*CentCOEFF(:,1)';  tvT=norm(tvT)*CentCOEFF(:,2)';
    
    tBranchPit=CentFivePit(1,:);
    CellQuadrantId=cell(4,1);
    
    [tX,tY]=meshgrid(1:nC,1:nR); tXY=[tX(:),tY(:)];  % Do not divide the embryo into 4 quadrants
    CellQuadrantId{3}=(tXY(:,1)-1)*nR+tXY(:,2);
    
    % Cut the continuous skeleton branches into multiple segments
    PixelBranchCell=cell(length(PixelBranch),4); % Divide into 4 quadrants
    for i=1:LenBranch
        tBranch=PixelBranch{i};
        tSkeletonPitId=(tBranch(:,1)-1)*nR+tBranch(:,2);
        
        for j=1:4
            tPixId=intersect(CellQuadrantId{j},tSkeletonPitId);
            tLen=length(tPixId);
            if tLen
                tIdSeq=zeros(tLen,1);
                for k=1:tLen
                    tIdSeq(k)=find(tSkeletonPitId==tPixId(k));
                end
                [tY,tX]=ind2sub([nR,nC],tSkeletonPitId(min(tIdSeq):max(tIdSeq)));
                PixelBranchCell{i,j}=[tX,tY];
            end
        end
    end % for i
    
    % Obtain the maximum length of each pixel
    LenMat=zeros(size(TT));
    for i=1:LenBranch
        for k=1:4
            tBranch=PixelBranchCell{i,k};
            tLen=length(tBranch);
            for j=1:tLen
                LenMat(tBranch(j,2),tBranch(j,1))=max(tLen,LenMat(tBranch(j,2),tBranch(j,1)));
            end
        end
    end % for i
    
    % Obtain the final distance*length
    ImgLenDist=zeros(nR,nC);
    for i=1:4
        if ~isempty(CellQuadrantId{i})
            ImgLenDist=ImgLenDist+DistSkeletonCenter([nR,nC],CellQuadrantId{i},LenMat);
        end
    end
    
    ImgLenDistCell{Num}=ImgLenDist; 
    
    %figure; imshow(ImgLenDist,[]);
    
    %% Optimize the branches with snake model
    SnakeOptimFun_interf;
end % for Num
toc
