function tOptDir=ModCentFivePit(CentFivePit,ConsidImg,tTheta)
% Locally perturb the central five points to mimimize the lighting sum 

[nR,nC,~]=size(ConsidImg);

CentPit=CentFivePit(5,:); % The center point

nPit=5; % The number of points on the line
n=5; tAn=10; % The number of approximated points and tried angles

tVecT=CentFivePit(1,:)-CentPit;  tMainLen=norm(tVecT);
tVecT=tVecT/norm(tVecT); tNormT=[tVecT(2),-tVecT(1)];

tDist=linspace(0,3*tMainLen,nPit)';
tDiscretePit=repmat(CentPit,nPit,1)+[tDist,tDist].*repmat(tVecT,nPit,1); % Center line

% The distance from the intersection points to the line BranchPit([1,5],:)
DiscretePit=zeros(n,nPit,2); % The basic trying parallel n lines
for i=1:n
    DiscretePit(i,:,:)=tDiscretePit+i*repmat(tNormT,nPit,1);
end 

tAngSequ=linspace(-tTheta,tTheta,tAn); % Rotation angles

%figure; imshow(tImg);
CurveTemp=cell(tAn,1); % Each contains n*nPit points
%CurveTemp=cell(tAn*n,1);
for i=1:tAn
    CurveTemp{i}=zeros(n,nPit,2);
    tAng=tAngSequ(i);
    tLocRotM=[cos(tAng),sin(tAng);-sin(tAng),cos(tAng)];
    
    for j=1:n
        tCentPits=repmat(CentPit,nPit,1);
        CurveTemp{i}(j,:,:)=tCentPits+(reshape(DiscretePit(j,:,:),nPit,2)-tCentPits)*tLocRotM;
        %hold on; plot(CurveTemp{(i-1)*n+j}(:,1),CurveTemp{(i-1)*n+j}(:,2),'-og');
    end
end % for i



%%
% Generate curve templates with width of 5
nCurv=length(CurveTemp);

nPitMo=50;
CurveTempNew=CurveTemp;

MinLig=-1e10; 
% Make the same length, the same number of points 
tValidLen=zeros(n,1);
for j=1:nCurv % For curvature of the curve
    CurveTempNew{j}=zeros(n,nPitMo,2);
    for k=1:n
        CurveTempNew{j}(k,:,:)=bs_curve_interpo_Fun(reshape(CurveTemp{j}(k,:,:),[],2),nPitMo);
    end
    CurveTempNew{j}=round(CurveTempNew{j});
    
    tId=(CurveTempNew{j}(:,:,1)-1)*nR+CurveTempNew{j}(:,:,2);
    tPixImg=ConsidImg(tId);
    for k=1:n % Maximize each trying line
        ttId=find(tPixImg(:,k)>0);
        if isempty(ttId)
            tPit=CurveTempNew{j}(k,end,:)-CurveTempNew{j}(k,1,:);
        else
            tPit=CurveTempNew{j}(k,ttId(1)-1,:)-CurveTempNew{j}(k,1,:);
        end
        tValidLen(k)=norm(reshape(tPit,[],2));
    end
    
    tNumLig=sum(tValidLen);
    if tNumLig>MinLig 
        MinLig=tNumLig; MinCurId=j;
    end 
end 

tOptDir=CurveTempNew{MinCurId}(1,nPit,:)-CurveTempNew{MinCurId}(1,1,:);
tOptDir=reshape(tOptDir,[],2);
tOptDir=tOptDir/norm(tOptDir);