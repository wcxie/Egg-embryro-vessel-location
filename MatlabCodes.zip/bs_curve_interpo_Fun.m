function vt=bs_curve_interpo_Fun(V,OutParaPit)
% For 2d, 3d curve interpolation

nr=size(V,1);
%nr=93;
%nr=7;
nk=3;  % The order of spline function
%nr denote rows of points matrix;
%nk denote the order of B spline we use to fit the points.

m=nr-1;n=m+nk-1;%denote m+1 initial points,n+1 dominated points.

%mut denote a temp vector for mu.
mut=zeros(1,m+1);
mut(1)=0;
for i=2:(m+1)
    %mut(i)=mut(i-1)+sqrt((V(i,1)-V(i-1,1))^2+(V(i,2)-V(i-1,2))^2+(V(i,3)-V(i-1,3))^2);
    mut(i)=mut(i-1)+sqrt(sum((V(i,:)-V(i-1,:)).^2));
end
mu=[zeros(1,n+1),ones(1,nk+1)]';
for i=2:m
    mu(3+i)=mut(i)/mut(m+1);
end


%D denote the dominated points computed according to V.
D=zeros(n+1,size(V,2));
D(1,:)=V(1,:);D(n+1,:)=V(m+1,:);
%compute dt(i.e. delta).dt_i=u_{i+1}-u_i,where u={u_0,...u_{n+nk+1}} is
%the endpoints vector.
dt=zeros(n+nk,1);
for i=1:(n+nk)
    dt(i)=mu(i+2)-mu(i+1);
end
%compute ai,bi,ci,ei, these notations is derived from P257 to evaluate
%dominate points by solving a set of equations.
ei=zeros(n-1,size(V,2));
%V(i-1,:) is equivalent to V(i,:), V(i,:) is the notation of the book.

%below is Free endpoint conditions.
ai(1)=2-dt(3)*dt(4)/(dt(3)+dt(4))^2;
bi(1)=dt(3)/(dt(3)+dt(4))*(dt(4)/(dt(3)+dt(4))-dt(3)/(dt(3)+dt(4)+dt(5)));
ci(1)=dt(3)^2/((dt(3)+dt(4))*(dt(3)+dt(4)+dt(5)));
ei(1,:)=V(1,:)+V(2,:);

ai(n-1)=-dt(n)^2/((dt(n-1)+dt(n))*(dt(n-2)+dt(n-1)+dt(n)));
bi(n-1)=dt(n)/(dt(n-1)+dt(n))*(dt(n)/(dt(n-2)+dt(n-1)+dt(n))-dt(n-1)/(dt(n-1)+dt(n)));
ci(n-1)=dt(n-1)*dt(n)/(dt(n-1)+dt(n))^2-2;
ei(n-1,:)=-V(m+1,:)-V(m,:);

for i=2:(n-2)
    ai(i)=dt(i+2)^2/(dt(i)+dt(i+1)+dt(i+2));
    bi(i)=dt(i+2)*(dt(i)+dt(i+1))/(dt(i)+dt(i+1)+dt(i+2))+dt(i+1)*(dt(i+2)+dt(i+3))/(dt(i+1)+dt(i+2)+dt(i+3));
    ci(i)=dt(i+1)^2/(dt(i+1)+dt(i+2)+dt(i+3));
    ei(i,:)=(dt(i+1)+dt(i+2))*V(i,:);
end %for(i)

%compute dominated points D.
A=zeros(n-1,n-1); %A is the coefficient matrix of the equations.
A(1,1:3)=[ai(1),bi(1),ci(1)];
A(n-1,(n-3):(n-1))=[ai(n-1),bi(n-1),ci(n-1)];
for i=2:(n-2)
    A(i,(i-1):(i+1))=[ai(i),bi(i),ci(i)];
end %for(i)
e=zeros(n-1,size(V,2));
for i=1:(n-1)
    e(i,:)=ei(i,:);
end %for(i)
D(2:n,:)=inv(A)*e;

if length(OutParaPit)==1 % Input the number of points
    N=OutParaPit-1; 
else  % Input the parameterization vector
    N=length(OutParaPit)-1; 
end % if 

vt=zeros(N+1,size(V,2));

for ti=1:(N+1)
    
    if length(OutParaPit)==1
        if (ti==N+1)
            u=0.9999;
        else
            u=(ti-1)/N;
        end
    else
        u=OutParaPit(ti)*(OutParaPit(ti)<0.9999)+0.9999*(OutParaPit(ti)>=0.9999);
    end % if 
    
    f=zeros(4,size(mu,1)-1);
    for j=1:(size(mu,1)-1)
        if ((u>=mu(j))&&(u<mu(j+1)))
            f(1,j)=1;
        else f(1,j)=0;
        end %for if
    end %for for
    
    for i=2:4  %compute to order 3,i=4 means the order is 3.
        for j=1:(size(mu,1)-i)
            if (mu(j+i-1)-mu(j)==0)
                t1=0;
            else t1=(u-mu(j))/(mu(j+i-1)-mu(j));
            end
            
            if (mu(j+i)-mu(j+1)==0)
                t2=0;
            else t2=(mu(j+i)-u)/(mu(j+i)-mu(j+1));
            end
            
            f(i,j)=t1*f(i-1,j)+t2*f(i-1,j+1);
        end
    end %for i
    
    f2=f(4,1:(n+1));

    vt(ti,:)=f2*D;
end %for ti
