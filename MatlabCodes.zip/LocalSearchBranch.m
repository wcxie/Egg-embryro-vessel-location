function [MinPix,QuadCurv,MinId,MinLig,tIntenM]=LocalSearchBranch(ConsidImg,BranchPit,Vtn,FlagQuad,CentPit)
% For locally adjust the leg direction
% FlagQuad--- Flag of quadrant

[nR,nC,~]=size(ConsidImg);

tLen=sum(sqrt(sum((BranchPit(2:end,:)-BranchPit(1:end-1,:)).^2,2)));

r=3/4*tLen;

mRot=Vtn; % The rotation matrix
tN=20; % The number of test points on the section
tAngSkew1=pi/6;  tAngSkew2=pi/15;
if FlagQuad==1
    tSeqAng=linspace(0+tAngSkew1,pi/2-tAngSkew2,tN)'; 
elseif FlagQuad==2
    tSeqAng=linspace(pi/2+tAngSkew2,pi-tAngSkew1,tN)'; 
elseif FlagQuad==3
    tSeqAng=linspace(pi+3/2*tAngSkew1,3*pi/2-tAngSkew2,tN)'; 
    %tSeqAng=linspace(pi+tAngSkew1,3*pi/2-tAngSkew2,tN)'; 
else
    tSeqAng=linspace(3*pi/2+tAngSkew2,2*pi-tAngSkew1,tN)'; 
end % if 

tPit=r*[cos(tSeqAng),sin(tSeqAng)]*mRot;

d=r/3; dN=10;  % The number of test lines below the line

tIntenM=1e10*ones(tN,dN);

if FlagQuad<=2 % Slightly perturb the point CentPit for the quadratic curve searching
    %CentPit=CentPit-50*Vtn(2,:);
    CentPit=CentPit-10*Vtn(2,:);
else
    %CentPit=CentPit+50*Vtn(2,:);
    CentPit=CentPit+10*Vtn(2,:);
end % if 

MinLig=1e10; MinId=[0,0]; MinPix=[]; QuadCurv={};
for i=1:tN
    tVecT=tPit(i,:)/r; 
    
    if FlagQuad<=2
        tTheta=acos(dot(tVecT,Vtn(1,:)));
    else
        tTheta=2*pi-acos(dot(tVecT,Vtn(1,:)));
    end % if 

    tLocRotM=[cos(tTheta),-sin(tTheta);sin(tTheta),cos(tTheta)];
    
    for j=1:dN
        ttd=(j-1)/dN*d;
        xSel=linspace(0,r,round(r))'; 
        if FlagQuad==2||FlagQuad==4
            aCoe=4*ttd/r^2;
        else
            aCoe=-4*ttd/r^2;
        end % if 
        ySel=aCoe*xSel.*(xSel-r);
        tTestPix=round(repmat(CentPit,length(xSel),1)+[xSel,ySel]*tLocRotM);
        tTestPix(:,1)=max(1,min(nC,tTestPix(:,1)));  tTestPix(:,2)=max(1,min(nR,tTestPix(:,2))); 
        
        %tIntenM(i,j)=sum(ConsidImg((tTestPix(:,1)-1)*nR+tTestPix(:,2)))/length(tTestPix);
        %tIntenM(i,j)=sum(ConsidImg((tTestPix(:,1)-1)*nR+tTestPix(:,2)));
        tIntenM(i,j)=-sum(ConsidImg((tTestPix(:,1)-1)*nR+tTestPix(:,2))<1e-3);
        
        if tIntenM(i,j)<MinLig
            MinLig=tIntenM(i,j); MinId=[i,j]; MinPix=tTestPix;
            QuadCurv={aCoe,r,CentPit,tLocRotM}; % tPix=CentPit+[x,a*x*(x-r)]*tLocRotM
        end % if 
    end % for j
end % for i

