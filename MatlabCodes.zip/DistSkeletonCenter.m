function smthLenDist=DistSkeletonCenter(ImgSize,tQuadrantId,LenMat)
% Compute the distance of the pixel in each quadrant to the skeleton center
% LenMat: The length of the skeleton line of eahc pixel
% tQuadrantId: The indices of pixels in the considered quadrant

nR=ImgSize(1);  nC=ImgSize(2);

smthLenDist=1e8*ones(nR,nC);

QuadLen=LenMat(tQuadrantId);
QuadLenValId=find(QuadLen); % Indices with positive length

QuadLenVal=QuadLen(QuadLenValId); % All the positive lengths

% Compute the distance from each pixel in tQuadrantId to QuadLenValId
[tY,tX]=ind2sub([nR,nC],tQuadrantId);
n=length(tX); % The length of pixels in the quadrant

tYp=tY(QuadLenValId); tXp=tX(QuadLenValId); % The coordinates with positive lengths
np=length(tXp);  % The length of pixels with positive lengths in the considered quadrant

%size(tX),np,size(tXp),n
tic
%DivNum=10;  % The matrix size in one time is too large for MATLAB use 
DivNum=1;  % The matrix size in one time is too large for MATLAB use 
LenWeightCoe=0.8;
%LenWeightCoe=1; % For GlobGuildField1
DivNumSeq=1+floor((n-1)/DivNum*[0:DivNum]);
for i=1:DivNum
    tNumSeq=[DivNumSeq(i):DivNumSeq(i+1)]; tLenNumSeq=length(tNumSeq);
    
    tDist=sqrt((repmat(tX(tNumSeq),1,np)-repmat(tXp',tLenNumSeq,1)).^2+(repmat(tY(tNumSeq),1,np)-repmat(tYp',tLenNumSeq,1)).^2);
    tDistLen=tDist.^LenWeightCoe./repmat(QuadLenVal',tLenNumSeq,1);
    smthLenDist(tQuadrantId(tNumSeq))=min(tDistLen,[],2);
end
toc