function [InterPit,CellModPix]=FindCurveCrossPit1(CurvCell,CentPit)
% Find the intersection point of two quadratic curves

%QuadCurv={aCoe,r,CentPit,tLocRotM}; % tPix=CentPit+[x,a*x*(x-r)]*tLocRotM

tTestPix=cell(2,1);
CellModPix=cell(2,2);
InterPit=zeros(2,2); % The final intersection point
for FlagLR=1:2
    if FlagLR==1
        Curv12=CurvCell([2:3]);
    else
        Curv12=CurvCell([1,4]);
    end %
    
    tTestPix{1}=Curv12{1}; tTestPix{2}=Curv12{2}; 
    tN1=size(tTestPix{1},1);  tN2=size(tTestPix{2},1);
    Flag=0;  CrossPos=[0,0];
    for i=1:tN1-1
        for j=1:tN2-1
            Pit1=tTestPix{1}([i,i+1],:);  Pit2=tTestPix{2}([j,j+1],:);
            if min(Pit1(:,1))>max(Pit2(:,1))||min(Pit2(:,1))>max(Pit1(:,1))||min(Pit1(:,2))>max(Pit2(:,2))||min(Pit2(:,2))>max(Pit1(:,2))
                continue;
            end % if
            
            ut=(Pit2(1,:)-Pit1(1,:))*pinv([Pit1(2,:)-Pit1(1,:);-(Pit2(2,:)-Pit2(1,:))]);
            if ut(1)>1||ut(1)<0||ut(2)>1||ut(2)<0
                continue;
            end % if
            
            InterPit(FlagLR,:)=Pit1(1,:)+ut(1)*(Pit1(2,:)-Pit1(1,:));
            Flag=1;
            CrossPos=[i,j];
            
            break;
        end
        
        if Flag  break;  end
    end
    
    if nargin>1  % Output the final curve
        for kk=1:2
            if norm(tTestPix{kk}(1,:)-CentPit)>norm(tTestPix{kk}(end,:)-CentPit)
                tTestPix{kk}=tTestPix{kk}(end:-1:1,:);
                CrossPos(kk)=size(tTestPix{kk},1)-CrossPos(kk)+1;
            end % if
            
            CellModPix{FlagLR,kk}=tTestPix{kk}(CrossPos(kk)+1:end,:);
        end % for kk
    end % if
end % for FlagLR

tCentPit=mean([CellModPix{1,1}(1,:);CellModPix{2,1}(1,:)]);
for FlagLR=1:2
    for kk=1:2
        CellModPix{FlagLR,kk}=[tCentPit;CellModPix{FlagLR,kk}];
    end 
end % for FlagLR

CellModPix([1:2])=CellModPix([2,1]);