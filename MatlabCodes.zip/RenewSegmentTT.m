% Separate the central skeleton parts from four quadrant pixels
% RenewSegmentTT;
% ContinEdge;
tBranchPit=EstShape(1,:);

% The original principal directions estimated by CentFivePit
Vtn=zeros(2,2); % The principal and normal directions of the branch
CentFivePit=EstShape(1:5,:);
Vtn(1,:)=CentFivePit(4,:)-CentFivePit(2,:); Vtn(1,:)=Vtn(1,:)/norm(Vtn(1,:));
Vtn(2,:)=[Vtn(1,2),-Vtn(1,1)];
if dot(Vtn(2,:),CentFivePit(3,:)-CentFivePit(1,:))<0
    Vtn(2,:)=-Vtn(2,:);
end % if

tPit=[tBranchPit;tBranchPit+10*Vtn(1,:);tBranchPit+10*Vtn(2,:)];

COEFF(:,1)=Vtn(2,:)';  COEFF(:,2)=Vtn(1,:)'; 

tPit=[tBranchPit;tBranchPit+10*COEFF(:,1)';tBranchPit+10*COEFF(:,2)'];

%
%figure; imshow(TT);
% Cut the skeleton branches in the first principal direction of COEFF
for tRatioLen=3:6 % Set the line points to black
    tCutHoriz=norm(CentFivePit(4,:)-CentFivePit(2,:))/tRatioLen; tCutVert=tCutHoriz*3;
    tSidePit=[tBranchPit-tCutHoriz*COEFF(:,2)';tBranchPit+tCutHoriz*COEFF(:,2)'];
    tLen=round(2*tCutVert); % The length of vertical cut line
    for i=1:2
        tPits=round(repmat(tSidePit(i,:),2*tLen,1)+tCutVert*repmat(([1:2*tLen]'-tLen)/tLen,1,2).*repmat(COEFF(:,1)',2*tLen,1));
        %hold on; plot(tPits(:,1),tPits(:,2),'.g');
        TT((tPits(:,1)-1)*nR+tPits(:,2))=0;
    end
end
%
