function [MinPix,MinId,MinLig,tIntenM]=LocalSearchBranch_1(ConsidImg,FlagQuad,CentPit,tvTN,OutNum,OutLen,vargin)
% For locally adjust the leg direction
% FlagQuad--- Flag of quadrant
% Add more curve templates

[nR,nC,~]=size(ConsidImg);

tvN=tvTN(2,:);  tvT=tvTN(1,:); 
% if FlagQuad==3
%     d=norm(tvN);   
% else
%     d=2*norm(tvN);   
% end

if nargin>6
    tPreInf=vargin;
    tvNt=tPreInf{1}; DistFlag=tPreInf{2};  tStPit=tPreInf{3};
end

n=4; 
if FlagQuad==3||FlagQuad==4
    d=1.5*norm(tvN); 
    CurveTemp=[];
else
    d=2*norm(tvN); 
     tTheta=0;
    CurveTemp=ParaCurveTemplate(d,tTheta,n); % Curve templates
end


% tTheta=0;
% CurveTemp=ParaCurveTemplate(d,tTheta,n); % Curve templates
%CurveTemp=[];

tTheta=-pi/10;
CurveTemp=[CurveTemp;ParaCurveTemplate(d,tTheta,n)]; % Curve templates
tTheta=-pi/5;
CurveTemp=[CurveTemp;ParaCurveTemplate(d,tTheta,n)]; % Curve templates
 tTheta=-pi/3;
 CurveTemp=[CurveTemp;ParaCurveTemplate(d,tTheta,n)]; % Curve templates


Vtn=tvTN;  Vtn(1,:)=Vtn(1,:)/norm(Vtn(1,:));  Vtn(2,:)=Vtn(2,:)/norm(Vtn(2,:)); 


mRot=Vtn; % The rotation matrix of the whole shape
tN=20; % The number of test points on the section

nCT=length(CurveTemp);
tIntenM=1e10*ones(tN,nCT);

if FlagQuad<=2
    tAngRegul=pi/2;   CentPit=CentPit-20*Vtn(2,:); % CentPit=CentPit-50*Vtn(2,:); 
else
    tAngRegul=3*pi/2; %CentPit=CentPit+50*Vtn(2,:);
end % if 
tRegulRotM=[cos(tAngRegul),sin(tAngRegul);-sin(tAngRegul),cos(tAngRegul)];

for j=1:nCT
    if FlagQuad==1||FlagQuad==3
        CurveTemp{j}=[CurveTemp{j}(:,1),-CurveTemp{j}(:,2)]*tRegulRotM;
    else
        CurveTemp{j}=CurveTemp{j}*tRegulRotM;
    end
end % if


MinLig=1e10; MinId=[0,0]; MinPix=[]; 

tAng1=pi/10; tAng2=pi/6;
if FlagQuad==1||FlagQuad==3
    ShapeRotAng=linspace(-tAng1,tAng2,tN);
else
    ShapeRotAng=linspace(-tAng2,tAng1,tN);
end % if 


AllTestPixel=cell(tN,nCT);
for i=1:tN % For local rotation angles
    tTheta=ShapeRotAng(i);

    tLocRotM=[cos(tTheta),sin(tTheta);-sin(tTheta),cos(tTheta)];
    
    for j=1:nCT % For curvature of the curve
        tDistVec=cumsum(sqrt(sum(abs(CurveTemp{j}(2:end,:)-CurveTemp{j}(1:end-1,:)).^2,2))); % Make the same length, the same number of points
        tPos=find(tDistVec>OutLen);
        if ~isempty(tPos)
            CurveTemp{j}=CurveTemp{j}(1:tPos(1),:);
        end % if 
        tTempPit=bs_curve_interpo_Fun(CurveTemp{j},OutNum);
        
        tTestPix=round(repmat(CentPit,size(tTempPit,1),1)+tTempPit*tLocRotM*mRot);
        tTestPix(:,1)=max(1,min(nC,tTestPix(:,1)));  tTestPix(:,2)=max(1,min(nR,tTestPix(:,2))); 
        
        % Test whether the points lie below the considered line
        if nargin>6
            ttn=size(tTestPix,1);
            if FlagQuad==3
                ttDist=sum(repmat(tvNt,ttn,1).*(tTestPix-repmat(tStPit,ttn,1)),2)*DistFlag(2); 
            elseif FlagQuad==4
                ttDist=sum(repmat(tvNt,ttn,1).*(tTestPix-repmat(tStPit,ttn,1)),2)*DistFlag(1); 
            end 
            
            if sum(ttDist>10)>ttn/10
                continue; % The candidate template is not considered 
            end
            
            %plot(tTestPix(:,1),tTestPix(:,2),'*g');   disp('ok!');   return;
        end
        
        %hold on; plot(tTestPix(:,1),tTestPix(:,2),'-b');
        if mod(j,2)==1
            %hold on; plot(tTestPix(:,1),tTestPix(:,2),'color',[i/tN,1-j/nCT,0]);
        end 

        tIntenM(i,j)=-sum(ConsidImg((tTestPix(:,1)-1)*nR+tTestPix(:,2))<1e-3);
        
        if tIntenM(i,j)<MinLig
            MinLig=tIntenM(i,j); MinId=[i,j]; MinPix=tTestPix;
        end % if 
        
        AllTestPixel{i,j}=tTestPix;
    end 
end % for i
